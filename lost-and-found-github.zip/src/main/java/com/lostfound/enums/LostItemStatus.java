package com.lostfound.enums;

public enum LostItemStatus {
    LOST("Lost"),
    FOUND_MATCHED("Matched"),
    RESOLVED("Resolved / Recovered"),
    WITHDRAWN("Withdrawn");

    private final String displayName;

    LostItemStatus(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}
