package com.lostfound.enums;

public enum FoundItemStatus {
    AVAILABLE("Available"),
    UNDER_CLAIM("Under Review"),
    CLAIMED("Claim Approved"),
    RETURNED("Returned to Owner"),
    WITHDRAWN("Withdrawn");

    private final String displayName;

    FoundItemStatus(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}
