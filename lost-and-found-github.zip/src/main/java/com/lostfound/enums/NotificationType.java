package com.lostfound.enums;

public enum NotificationType {
    CLAIM_UPDATE("Claim Update"),
    MATCH_FOUND("Potential Match Found"),
    ITEM_STATUS("Item Status Update"),
    ADMIN_ALERT("Administrative Alert");

    private final String displayName;

    NotificationType(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}
