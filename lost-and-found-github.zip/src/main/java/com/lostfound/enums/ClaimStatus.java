package com.lostfound.enums;

public enum ClaimStatus {
    PENDING("Pending Verification"),
    APPROVED("Approved"),
    REJECTED("Rejected"),
    RETURNED("Item Returned");

    private final String displayName;

    ClaimStatus(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}
