package com.lostfound.enums;

public enum MatchStatus {
    POTENTIAL("Potential Match"),
    CONFIRMED("Confirmed Match"),
    DISMISSED("Dismissed");

    private final String displayName;

    MatchStatus(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}
