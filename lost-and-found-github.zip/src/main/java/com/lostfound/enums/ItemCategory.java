package com.lostfound.enums;

public enum ItemCategory {
    ID_CARD("Identity Card"),
    WALLET_PURSE("Wallet or Purse"),
    KEYS("Keys"),
    BOOKS_NOTEBOOKS("Books and Notebooks"),
    CALCULATOR("Calculator"),
    ELECTRONICS("Electronics"),
    WATER_BOTTLE("Water Bottle"),
    BAGS("Bags"),
    STATIONERY("Stationery"),
    CLOTHING("Clothing"),
    OTHER("Other");

    private final String displayName;

    ItemCategory(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}
