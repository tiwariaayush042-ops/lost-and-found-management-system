package com.lostfound.config;

import com.lostfound.entity.*;
import com.lostfound.enums.*;
import com.lostfound.repository.*;
import com.lostfound.service.ItemMatchService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.Optional;

@Component
public class DataInitializer implements CommandLineRunner {

    private static final Logger logger = LoggerFactory.getLogger(DataInitializer.class);

    private final UserRepository userRepository;
    private final LostItemRepository lostItemRepository;
    private final FoundItemRepository foundItemRepository;
    private final ItemMatchService itemMatchService;
    private final PasswordEncoder passwordEncoder;

    @Value("${lostfound.admin.email:admin@campus.edu}")
    private String adminEmail;

    @Value("${lostfound.admin.password:Admin@12345}")
    private String adminPassword;

    @Value("${lostfound.admin.name:Campus Administrator}")
    private String adminName;

    public DataInitializer(UserRepository userRepository,
                           LostItemRepository lostItemRepository,
                           FoundItemRepository foundItemRepository,
                           ItemMatchService itemMatchService,
                           PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.lostItemRepository = lostItemRepository;
        this.foundItemRepository = foundItemRepository;
        this.itemMatchService = itemMatchService;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {
        initializeAdministrator();
        initializeSampleCampusData();
    }

    private void initializeAdministrator() {
        Optional<User> existingAdmin = userRepository.findByEmail(adminEmail.toLowerCase().trim());
        if (existingAdmin.isEmpty()) {
            User admin = new User(
                    adminName,
                    adminEmail.toLowerCase().trim(),
                    passwordEncoder.encode(adminPassword),
                    Role.ROLE_ADMIN,
                    "ADM-001"
            );
            userRepository.save(admin);
            logger.info(">>> Initial Administrator account initialized successfully: {} [ROLE_ADMIN]", adminEmail);
        } else {
            logger.info("Administrator account already present: {}", adminEmail);
        }
    }

    private void initializeSampleCampusData() {
        // Seed demo data only if there are no lost/found items currently in the system
        if (lostItemRepository.count() > 0 || foundItemRepository.count() > 0) {
            return;
        }

        logger.info("Initializing initial demonstration campus data for review & viva demonstration...");

        // Create Demo Student
        User student = userRepository.findByEmail("student@campus.edu").orElseGet(() -> {
            User s = new User("Aarav Sharma [Demo Student]", "student@campus.edu",
                    passwordEncoder.encode("Student@12345"), Role.ROLE_STUDENT, "23AIML042");
            return userRepository.save(s);
        });

        // Create Demo Staff Member
        User staff = userRepository.findByEmail("staff@campus.edu").orElseGet(() -> {
            User st = new User("Dr. Rajesh Kumar [Demo Staff]", "staff@campus.edu",
                    passwordEncoder.encode("Staff@12345"), Role.ROLE_STAFF, "FAC-CS-108");
            return userRepository.save(st);
        });

        // Create Demo Finder Student
        User student2 = userRepository.findByEmail("priya@campus.edu").orElseGet(() -> {
            User s2 = new User("Priya Patel [Demo Student]", "priya@campus.edu",
                    passwordEncoder.encode("Priya@12345"), Role.ROLE_STUDENT, "23AIML088");
            return userRepository.save(s2);
        });

        // 1. Lost Item: Student ID Card
        LostItem lostId = new LostItem(
                student,
                "AIML Student Identity Card",
                ItemCategory.ID_CARD,
                "Blue lanyard identity card with student name Aarav Sharma and roll number 23AIML042.",
                "Main Library, 2nd Floor Reading Hall",
                LocalDate.now().minusDays(1),
                "Around 3:30 PM",
                null
        );
        lostId = lostItemRepository.save(lostId);

        // 2. Found Item: Student ID Card (Will produce strong match!)
        FoundItem foundId = new FoundItem(
                student2,
                "College Student ID Card with Blue Lanyard",
                ItemCategory.ID_CARD,
                "Found a college ID card with blue lanyard near the reading desk in the central library.",
                "Central Library Reading Room",
                LocalDate.now().minusDays(1),
                "Around 4:15 PM",
                null
        );
        foundId = foundItemRepository.save(foundId);

        // Run matching between them
        itemMatchService.runMatchingForLostItem(lostId);

        // 3. Lost Item: Casio Scientific Calculator
        LostItem lostCalc = new LostItem(
                student,
                "Casio fx-991EX Scientific Calculator",
                ItemCategory.CALCULATOR,
                "Black Casio fx-991EX classwiz calculator with a small white barcode sticker on the back cover.",
                "Block B - Room 204",
                LocalDate.now().minusDays(3),
                "Morning class ~11:00 AM",
                null
        );
        lostItemRepository.save(lostCalc);

        // 4. Found Item: Calculator in Block B
        FoundItem foundCalc = new FoundItem(
                staff,
                "Casio Scientific Calculator fx-991",
                ItemCategory.CALCULATOR,
                "Left behind on the front desk after the AIML lab lecture in Block B Room 204.",
                "Block B - Room 204",
                LocalDate.now().minusDays(3),
                "12:00 PM",
                null
        );
        foundCalc = foundItemRepository.save(foundCalc);
        itemMatchService.runMatchingForLostItem(lostCalc);

        // 5. Found Item: Stainless Steel Water Bottle
        FoundItem foundBottle = new FoundItem(
                student2,
                "Milton Silver Stainless Steel Water Bottle",
                ItemCategory.WATER_BOTTLE,
                "Silver 750ml water bottle with a small dent at the bottom.",
                "Campus Sports Complex / Gymnasium",
                LocalDate.now().minusDays(2),
                "5:00 PM",
                null
        );
        foundItemRepository.save(foundBottle);

        // 6. Returned Item: Keys with Honda keychain
        FoundItem returnedKeys = new FoundItem(
                staff,
                "Set of 3 Keys with Red Honda Keychain",
                ItemCategory.KEYS,
                "Found near Parking Lot Gate 2 and handed to campus security.",
                "Student Parking Lot Gate 2",
                LocalDate.now().minusDays(5),
                "9:15 AM",
                null
        );
        returnedKeys.setStatus(FoundItemStatus.RETURNED);
        foundItemRepository.save(returnedKeys);

        logger.info(">>> Initial demonstration data seeded successfully.");
    }
}
