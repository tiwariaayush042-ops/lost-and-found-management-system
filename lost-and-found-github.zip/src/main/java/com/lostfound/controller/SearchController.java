package com.lostfound.controller;

import com.lostfound.dto.ItemSearchCriteria;
import com.lostfound.entity.FoundItem;
import com.lostfound.entity.LostItem;
import com.lostfound.enums.FoundItemStatus;
import com.lostfound.enums.ItemCategory;
import com.lostfound.enums.LostItemStatus;
import com.lostfound.service.FoundItemService;
import com.lostfound.service.LostItemService;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

@Controller
public class SearchController {

    private final LostItemService lostItemService;
    private final FoundItemService foundItemService;

    public SearchController(LostItemService lostItemService, FoundItemService foundItemService) {
        this.lostItemService = lostItemService;
        this.foundItemService = foundItemService;
    }

    @GetMapping("/search")
    public String search(@ModelAttribute("criteria") ItemSearchCriteria criteria, Model model) {
        String type = criteria.getType() != null ? criteria.getType().toUpperCase() : "ALL";

        Page<LostItem> lostPage = null;
        Page<FoundItem> foundPage = null;

        if ("LOST".equals(type)) {
            lostPage = lostItemService.search(criteria);
        } else if ("FOUND".equals(type)) {
            foundPage = foundItemService.search(criteria);
        } else {
            // "ALL": Search both
            lostPage = lostItemService.search(criteria);
            foundPage = foundItemService.search(criteria);
        }

        model.addAttribute("type", type);
        model.addAttribute("lostPage", lostPage);
        model.addAttribute("foundPage", foundPage);
        model.addAttribute("categories", ItemCategory.values());
        model.addAttribute("lostStatuses", LostItemStatus.values());
        model.addAttribute("foundStatuses", FoundItemStatus.values());

        return "items/search";
    }
}
