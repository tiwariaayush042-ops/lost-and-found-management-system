package com.lostfound.controller;

import com.lostfound.dto.DashboardStatsDto;
import com.lostfound.dto.ItemSearchCriteria;
import com.lostfound.entity.FoundItem;
import com.lostfound.entity.LostItem;
import com.lostfound.enums.ItemCategory;
import com.lostfound.service.DashboardService;
import com.lostfound.service.FoundItemService;
import com.lostfound.service.LostItemService;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    private final DashboardService dashboardService;
    private final LostItemService lostItemService;
    private final FoundItemService foundItemService;

    public HomeController(DashboardService dashboardService,
                          LostItemService lostItemService,
                          FoundItemService foundItemService) {
        this.dashboardService = dashboardService;
        this.lostItemService = lostItemService;
        this.foundItemService = foundItemService;
    }

    @GetMapping({"/", "/home"})
    public String home(Model model) {
        DashboardStatsDto stats = dashboardService.getDashboardStatistics();
        model.addAttribute("stats", stats);

        // Fetch recent active lost items (up to 4)
        ItemSearchCriteria lostCriteria = new ItemSearchCriteria();
        lostCriteria.setSize(4);
        lostCriteria.setStatus("LOST");
        Page<LostItem> recentLost = lostItemService.search(lostCriteria);
        model.addAttribute("recentLost", recentLost.getContent());

        // Fetch recent available found items (up to 4)
        ItemSearchCriteria foundCriteria = new ItemSearchCriteria();
        foundCriteria.setSize(4);
        foundCriteria.setStatus("AVAILABLE");
        Page<FoundItem> recentFound = foundItemService.search(foundCriteria);
        model.addAttribute("recentFound", recentFound.getContent());

        model.addAttribute("categories", ItemCategory.values());
        return "index";
    }
}
