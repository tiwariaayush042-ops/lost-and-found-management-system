package com.lostfound.controller;

import com.lostfound.dto.FoundItemDto;
import com.lostfound.entity.FoundItem;
import com.lostfound.entity.ItemMatch;
import com.lostfound.entity.User;
import com.lostfound.enums.FoundItemStatus;
import com.lostfound.enums.ItemCategory;
import com.lostfound.enums.Role;
import com.lostfound.service.FoundItemService;
import com.lostfound.service.ItemMatchService;
import com.lostfound.service.UserService;
import jakarta.validation.Valid;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/found-items")
public class FoundItemController {

    private final FoundItemService foundItemService;
    private final UserService userService;
    private final ItemMatchService itemMatchService;

    public FoundItemController(FoundItemService foundItemService,
                               UserService userService,
                               ItemMatchService itemMatchService) {
        this.foundItemService = foundItemService;
        this.userService = userService;
        this.itemMatchService = itemMatchService;
    }

    @GetMapping("/report")
    public String showReportForm(Model model) {
        if (!model.containsAttribute("foundItemDto")) {
            model.addAttribute("foundItemDto", new FoundItemDto());
        }
        model.addAttribute("categories", ItemCategory.values());
        return "items/report-found";
    }

    @PostMapping("/report")
    public String submitReport(@Valid @ModelAttribute("foundItemDto") FoundItemDto dto,
                               BindingResult bindingResult,
                               @AuthenticationPrincipal UserDetails userDetails,
                               Model model,
                               RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("categories", ItemCategory.values());
            return "items/report-found";
        }

        User user = userService.findByEmail(userDetails.getUsername()).orElseThrow();
        FoundItem saved = foundItemService.createFoundItem(dto, user);

        redirectAttributes.addFlashAttribute("successMessage",
                "Your found item registration has been recorded! Thank you for helping our campus community.");
        return "redirect:/found-items/" + saved.getId();
    }

    @GetMapping("/{id}")
    public String viewDetails(@PathVariable("id") Long id,
                              @AuthenticationPrincipal UserDetails userDetails,
                              Model model) {
        FoundItem item = foundItemService.getById(id);
        model.addAttribute("item", item);

        boolean isOwner = false;
        boolean isAdmin = false;
        boolean canClaim = false;

        if (userDetails != null) {
            User currentUser = userService.findByEmail(userDetails.getUsername()).orElse(null);
            if (currentUser != null) {
                isOwner = item.getReporter().getId().equals(currentUser.getId());
                isAdmin = currentUser.getRole() == Role.ROLE_ADMIN;
                // A user can submit a claim if they are not the person who reported the item found,
                // and the item is either AVAILABLE or UNDER_CLAIM
                canClaim = !isOwner && (item.getStatus() == FoundItemStatus.AVAILABLE || item.getStatus() == FoundItemStatus.UNDER_CLAIM);
            }
        }

        model.addAttribute("isOwner", isOwner);
        model.addAttribute("isAdmin", isAdmin);
        model.addAttribute("canClaim", canClaim);

        if (isOwner || isAdmin) {
            List<ItemMatch> matches = itemMatchService.getMatchesForFoundItem(item);
            model.addAttribute("matches", matches);
        }

        return "items/found-details";
    }

    @GetMapping("/{id}/edit")
    public String showEditForm(@PathVariable("id") Long id,
                               @AuthenticationPrincipal UserDetails userDetails,
                               Model model) {
        FoundItem item = foundItemService.getById(id);
        User user = userService.findByEmail(userDetails.getUsername()).orElseThrow();

        boolean isOwner = item.getReporter().getId().equals(user.getId());
        boolean isAdmin = user.getRole() == Role.ROLE_ADMIN;

        if (!isOwner && !isAdmin) {
            return "redirect:/error/403";
        }

        FoundItemDto dto = new FoundItemDto();
        dto.setId(item.getId());
        dto.setTitle(item.getTitle());
        dto.setCategory(item.getCategory());
        dto.setDescription(item.getDescription());
        dto.setLocationFound(item.getLocationFound());
        dto.setDateFound(item.getDateFound());
        dto.setTimeFoundApprox(item.getTimeFoundApprox());
        dto.setExistingImagePath(item.getImagePath());

        model.addAttribute("foundItemDto", dto);
        model.addAttribute("item", item);
        model.addAttribute("categories", ItemCategory.values());
        return "items/edit-found";
    }

    @PostMapping("/{id}/edit")
    public String submitEdit(@PathVariable("id") Long id,
                             @Valid @ModelAttribute("foundItemDto") FoundItemDto dto,
                             BindingResult bindingResult,
                             @AuthenticationPrincipal UserDetails userDetails,
                             Model model,
                             RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("categories", ItemCategory.values());
            return "items/edit-found";
        }

        User user = userService.findByEmail(userDetails.getUsername()).orElseThrow();
        foundItemService.updateFoundItem(id, dto, user);

        redirectAttributes.addFlashAttribute("successMessage", "Found item report updated successfully.");
        return "redirect:/found-items/" + id;
    }

    @PostMapping("/{id}/withdraw")
    public String withdrawReport(@PathVariable("id") Long id,
                                 @AuthenticationPrincipal UserDetails userDetails,
                                 RedirectAttributes redirectAttributes) {
        User user = userService.findByEmail(userDetails.getUsername()).orElseThrow();
        foundItemService.withdrawFoundItem(id, user);

        redirectAttributes.addFlashAttribute("successMessage", "Found item report has been withdrawn.");
        return "redirect:/found-items/" + id;
    }

    @GetMapping("/my")
    public String myFoundItems(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User user = userService.findByEmail(userDetails.getUsername()).orElseThrow();
        List<FoundItem> items = foundItemService.getReportsByUser(user);
        model.addAttribute("items", items);
        return "items/my-found";
    }
}
