package com.lostfound.controller;

import com.lostfound.dto.ClaimReviewDto;
import com.lostfound.dto.DashboardStatsDto;
import com.lostfound.dto.ItemSearchCriteria;
import com.lostfound.entity.*;
import com.lostfound.enums.AccountStatus;
import com.lostfound.enums.ClaimStatus;
import com.lostfound.enums.Role;
import com.lostfound.service.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/admin")
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {

    private final DashboardService dashboardService;
    private final LostItemService lostItemService;
    private final FoundItemService foundItemService;
    private final ClaimService claimService;
    private final UserService userService;
    private final AuditLogService auditLogService;

    public AdminController(DashboardService dashboardService,
                           LostItemService lostItemService,
                           FoundItemService foundItemService,
                           ClaimService claimService,
                           UserService userService,
                           AuditLogService auditLogService) {
        this.dashboardService = dashboardService;
        this.lostItemService = lostItemService;
        this.foundItemService = foundItemService;
        this.claimService = claimService;
        this.userService = userService;
        this.auditLogService = auditLogService;
    }

    @GetMapping("/dashboard")
    public String adminDashboard(Model model) {
        DashboardStatsDto stats = dashboardService.getDashboardStatistics();
        model.addAttribute("stats", stats);
        model.addAttribute("recentLogs", auditLogService.getRecentLogs());
        return "admin/dashboard";
    }

    @GetMapping("/reports")
    public String manageReports(@RequestParam(value = "type", defaultValue = "lost") String type,
                                @RequestParam(value = "page", defaultValue = "0") int page,
                                Model model) {
        ItemSearchCriteria criteria = new ItemSearchCriteria();
        criteria.setPage(page);
        criteria.setSize(10);

        if ("found".equalsIgnoreCase(type)) {
            Page<FoundItem> foundItems = foundItemService.search(criteria);
            model.addAttribute("items", foundItems);
            model.addAttribute("type", "found");
        } else {
            Page<LostItem> lostItems = lostItemService.search(criteria);
            model.addAttribute("items", lostItems);
            model.addAttribute("type", "lost");
        }

        return "admin/reports";
    }

    @GetMapping("/claims")
    public String reviewClaims(@RequestParam(value = "status", required = false) String statusStr,
                               @RequestParam(value = "page", defaultValue = "0") int page,
                               Model model) {
        Pageable pageable = PageRequest.of(page, 10);
        Page<Claim> claims;

        if (statusStr != null && !statusStr.isBlank()) {
            try {
                ClaimStatus status = ClaimStatus.valueOf(statusStr.toUpperCase());
                claims = claimService.getClaimsByStatus(status, pageable);
                model.addAttribute("selectedStatus", statusStr);
            } catch (IllegalArgumentException e) {
                claims = claimService.getAllClaims(pageable);
            }
        } else {
            claims = claimService.getAllClaims(pageable);
        }

        model.addAttribute("claims", claims);
        model.addAttribute("statuses", ClaimStatus.values());
        model.addAttribute("reviewDto", new ClaimReviewDto());
        return "admin/claims";
    }

    @GetMapping("/users")
    public String manageUsers(@RequestParam(value = "page", defaultValue = "0") int page, Model model) {
        Pageable pageable = PageRequest.of(page, 15);
        Page<User> users = userService.getAllUsers(pageable);
        model.addAttribute("users", users);
        model.addAttribute("roles", Role.values());
        model.addAttribute("statuses", AccountStatus.values());
        return "admin/users";
    }

    @PostMapping("/users/{id}/status")
    public String updateUserStatus(@PathVariable("id") Long id,
                                   @RequestParam("status") AccountStatus status,
                                   @AuthenticationPrincipal UserDetails userDetails,
                                   RedirectAttributes redirectAttributes) {
        try {
            userService.updateUserStatus(id, status, userDetails.getUsername());
            redirectAttributes.addFlashAttribute("successMessage", "User account status updated to " + status.getDisplayName());
        } catch (Exception ex) {
            redirectAttributes.addFlashAttribute("errorMessage", ex.getMessage());
        }
        return "redirect:/admin/users";
    }

    @PostMapping("/users/{id}/role")
    public String updateUserRole(@PathVariable("id") Long id,
                                 @RequestParam("role") Role role,
                                 @AuthenticationPrincipal UserDetails userDetails,
                                 RedirectAttributes redirectAttributes) {
        try {
            userService.updateUserRole(id, role, userDetails.getUsername());
            redirectAttributes.addFlashAttribute("successMessage", "User role changed to " + role.getDisplayName());
        } catch (Exception ex) {
            redirectAttributes.addFlashAttribute("errorMessage", ex.getMessage());
        }
        return "redirect:/admin/users";
    }

    @GetMapping("/audit")
    public String viewAuditLogs(@RequestParam(value = "page", defaultValue = "0") int page, Model model) {
        Pageable pageable = PageRequest.of(page, 20);
        Page<AuditLog> auditLogs = auditLogService.getAuditLogs(pageable);
        model.addAttribute("auditLogs", auditLogs);
        return "admin/audit";
    }
}
