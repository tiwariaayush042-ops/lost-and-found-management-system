package com.lostfound.controller;

import com.lostfound.entity.*;
import com.lostfound.enums.LostItemStatus;
import com.lostfound.enums.Role;
import com.lostfound.service.*;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class StudentDashboardController {

    private final UserService userService;
    private final LostItemService lostItemService;
    private final FoundItemService foundItemService;
    private final ClaimService claimService;
    private final ItemMatchService itemMatchService;
    private final NotificationService notificationService;

    public StudentDashboardController(UserService userService,
                                      LostItemService lostItemService,
                                      FoundItemService foundItemService,
                                      ClaimService claimService,
                                      ItemMatchService itemMatchService,
                                      NotificationService notificationService) {
        this.userService = userService;
        this.lostItemService = lostItemService;
        this.foundItemService = foundItemService;
        this.claimService = claimService;
        this.itemMatchService = itemMatchService;
        this.notificationService = notificationService;
    }

    @GetMapping("/dashboard")
    public String dashboard(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        if (userDetails == null) {
            return "redirect:/login";
        }

        User user = userService.findByEmail(userDetails.getUsername())
                .orElseThrow(() -> new IllegalStateException("User not found: " + userDetails.getUsername()));

        // If administrator, redirect to admin dashboard
        if (user.getRole() == Role.ROLE_ADMIN) {
            return "redirect:/admin/dashboard";
        }

        List<LostItem> myLostItems = lostItemService.getReportsByUser(user);
        List<FoundItem> myFoundItems = foundItemService.getReportsByUser(user);
        List<Claim> myClaims = claimService.getClaimsByUser(user);

        // Count potential matches for active lost items
        long totalPotentialMatches = 0;
        for (LostItem lost : myLostItems) {
            if (lost.getStatus() == LostItemStatus.LOST) {
                totalPotentialMatches += itemMatchService.getMatchesForLostItem(lost).size();
            }
        }

        long unreadNotifications = notificationService.getUnreadCount(user);
        List<Notification> recentNotifications = notificationService.getUserNotifications(user);
        if (recentNotifications.size() > 5) {
            recentNotifications = recentNotifications.subList(0, 5);
        }

        model.addAttribute("user", user);
        model.addAttribute("myLostItems", myLostItems);
        model.addAttribute("myFoundItems", myFoundItems);
        model.addAttribute("myClaims", myClaims);
        model.addAttribute("potentialMatchesCount", totalPotentialMatches);
        model.addAttribute("unreadNotifications", unreadNotifications);
        model.addAttribute("recentNotifications", recentNotifications);

        return "dashboard/student";
    }
}
