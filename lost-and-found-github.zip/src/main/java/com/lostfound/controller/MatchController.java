package com.lostfound.controller;

import com.lostfound.entity.ItemMatch;
import com.lostfound.entity.LostItem;
import com.lostfound.entity.User;
import com.lostfound.enums.Role;
import com.lostfound.service.ItemMatchService;
import com.lostfound.service.LostItemService;
import com.lostfound.service.UserService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/matches")
public class MatchController {

    private final LostItemService lostItemService;
    private final ItemMatchService itemMatchService;
    private final UserService userService;

    public MatchController(LostItemService lostItemService,
                           ItemMatchService itemMatchService,
                           UserService userService) {
        this.lostItemService = lostItemService;
        this.itemMatchService = itemMatchService;
        this.userService = userService;
    }

    @GetMapping("/lost/{lostItemId}")
    public String viewMatchesForLostItem(@PathVariable("lostItemId") Long lostItemId,
                                         @AuthenticationPrincipal UserDetails userDetails,
                                         Model model) {
        LostItem lostItem = lostItemService.getById(lostItemId);
        User currentUser = userService.findByEmail(userDetails.getUsername()).orElseThrow();

        boolean isOwner = lostItem.getReporter().getId().equals(currentUser.getId());
        boolean isAdmin = currentUser.getRole() == Role.ROLE_ADMIN;

        if (!isOwner && !isAdmin) {
            return "redirect:/error/403";
        }

        List<ItemMatch> matches = itemMatchService.getMatchesForLostItem(lostItem);

        model.addAttribute("lostItem", lostItem);
        model.addAttribute("matches", matches);
        return "matches/lost-matches";
    }
}
