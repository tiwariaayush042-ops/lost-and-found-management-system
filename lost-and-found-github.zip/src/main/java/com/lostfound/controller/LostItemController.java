package com.lostfound.controller;

import com.lostfound.dto.LostItemDto;
import com.lostfound.entity.ItemMatch;
import com.lostfound.entity.LostItem;
import com.lostfound.entity.User;
import com.lostfound.enums.ItemCategory;
import com.lostfound.enums.Role;
import com.lostfound.service.ItemMatchService;
import com.lostfound.service.LostItemService;
import com.lostfound.service.UserService;
import jakarta.validation.Valid;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/lost-items")
public class LostItemController {

    private final LostItemService lostItemService;
    private final UserService userService;
    private final ItemMatchService itemMatchService;

    public LostItemController(LostItemService lostItemService,
                              UserService userService,
                              ItemMatchService itemMatchService) {
        this.lostItemService = lostItemService;
        this.userService = userService;
        this.itemMatchService = itemMatchService;
    }

    @GetMapping("/report")
    public String showReportForm(Model model) {
        if (!model.containsAttribute("lostItemDto")) {
            model.addAttribute("lostItemDto", new LostItemDto());
        }
        model.addAttribute("categories", ItemCategory.values());
        return "items/report-lost";
    }

    @PostMapping("/report")
    public String submitReport(@Valid @ModelAttribute("lostItemDto") LostItemDto dto,
                               BindingResult bindingResult,
                               @AuthenticationPrincipal UserDetails userDetails,
                               Model model,
                               RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("categories", ItemCategory.values());
            return "items/report-lost";
        }

        User user = userService.findByEmail(userDetails.getUsername()).orElseThrow();
        LostItem saved = lostItemService.createLostItem(dto, user);

        redirectAttributes.addFlashAttribute("successMessage",
                "Your lost item report has been registered successfully! Our system is scanning for matching found items.");
        return "redirect:/lost-items/" + saved.getId();
    }

    @GetMapping("/{id}")
    public String viewDetails(@PathVariable("id") Long id,
                              @AuthenticationPrincipal UserDetails userDetails,
                              Model model) {
        LostItem item = lostItemService.getById(id);
        model.addAttribute("item", item);

        boolean isOwner = false;
        boolean isAdmin = false;

        if (userDetails != null) {
            User currentUser = userService.findByEmail(userDetails.getUsername()).orElse(null);
            if (currentUser != null) {
                isOwner = item.getReporter().getId().equals(currentUser.getId());
                isAdmin = currentUser.getRole() == Role.ROLE_ADMIN;
            }
        }

        model.addAttribute("isOwner", isOwner);
        model.addAttribute("isAdmin", isAdmin);

        // Fetch potential matches if viewer is owner or admin
        if (isOwner || isAdmin) {
            List<ItemMatch> matches = itemMatchService.getMatchesForLostItem(item);
            model.addAttribute("matches", matches);
        }

        return "items/lost-details";
    }

    @GetMapping("/{id}/edit")
    public String showEditForm(@PathVariable("id") Long id,
                               @AuthenticationPrincipal UserDetails userDetails,
                               Model model) {
        LostItem item = lostItemService.getById(id);
        User user = userService.findByEmail(userDetails.getUsername()).orElseThrow();

        boolean isOwner = item.getReporter().getId().equals(user.getId());
        boolean isAdmin = user.getRole() == Role.ROLE_ADMIN;

        if (!isOwner && !isAdmin) {
            return "redirect:/error/403";
        }

        LostItemDto dto = new LostItemDto();
        dto.setId(item.getId());
        dto.setTitle(item.getTitle());
        dto.setCategory(item.getCategory());
        dto.setDescription(item.getDescription());
        dto.setLastKnownLocation(item.getLastKnownLocation());
        dto.setDateLost(item.getDateLost());
        dto.setTimeLostApprox(item.getTimeLostApprox());
        dto.setExistingImagePath(item.getImagePath());

        model.addAttribute("lostItemDto", dto);
        model.addAttribute("item", item);
        model.addAttribute("categories", ItemCategory.values());
        return "items/edit-lost";
    }

    @PostMapping("/{id}/edit")
    public String submitEdit(@PathVariable("id") Long id,
                             @Valid @ModelAttribute("lostItemDto") LostItemDto dto,
                             BindingResult bindingResult,
                             @AuthenticationPrincipal UserDetails userDetails,
                             Model model,
                             RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("categories", ItemCategory.values());
            return "items/edit-lost";
        }

        User user = userService.findByEmail(userDetails.getUsername()).orElseThrow();
        lostItemService.updateLostItem(id, dto, user);

        redirectAttributes.addFlashAttribute("successMessage", "Lost report updated successfully.");
        return "redirect:/lost-items/" + id;
    }

    @PostMapping("/{id}/withdraw")
    public String withdrawReport(@PathVariable("id") Long id,
                                 @AuthenticationPrincipal UserDetails userDetails,
                                 RedirectAttributes redirectAttributes) {
        User user = userService.findByEmail(userDetails.getUsername()).orElseThrow();
        lostItemService.withdrawLostItem(id, user);

        redirectAttributes.addFlashAttribute("successMessage", "Lost item report has been withdrawn.");
        return "redirect:/lost-items/" + id;
    }

    @GetMapping("/my")
    public String myLostItems(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User user = userService.findByEmail(userDetails.getUsername()).orElseThrow();
        List<LostItem> items = lostItemService.getReportsByUser(user);
        model.addAttribute("items", items);
        return "items/my-lost";
    }
}
