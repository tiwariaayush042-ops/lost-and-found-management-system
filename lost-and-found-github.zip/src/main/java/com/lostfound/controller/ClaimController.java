package com.lostfound.controller;

import com.lostfound.dto.ClaimRequestDto;
import com.lostfound.dto.ClaimReviewDto;
import com.lostfound.entity.Claim;
import com.lostfound.entity.FoundItem;
import com.lostfound.entity.User;
import com.lostfound.service.ClaimService;
import com.lostfound.service.FoundItemService;
import com.lostfound.service.UserService;
import jakarta.validation.Valid;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/claims")
public class ClaimController {

    private final ClaimService claimService;
    private final FoundItemService foundItemService;
    private final UserService userService;

    public ClaimController(ClaimService claimService,
                           FoundItemService foundItemService,
                           UserService userService) {
        this.claimService = claimService;
        this.foundItemService = foundItemService;
        this.userService = userService;
    }

    @GetMapping("/submit/{foundItemId}")
    public String showClaimForm(@PathVariable("foundItemId") Long foundItemId,
                                @AuthenticationPrincipal UserDetails userDetails,
                                Model model,
                                RedirectAttributes redirectAttributes) {
        FoundItem foundItem = foundItemService.getById(foundItemId);
        User currentUser = userService.findByEmail(userDetails.getUsername()).orElseThrow();

        if (foundItem.getReporter().getId().equals(currentUser.getId())) {
            redirectAttributes.addFlashAttribute("errorMessage", "You cannot claim an item that you reported found yourself.");
            return "redirect:/found-items/" + foundItemId;
        }

        ClaimRequestDto dto = new ClaimRequestDto();
        dto.setFoundItemId(foundItemId);

        model.addAttribute("foundItem", foundItem);
        model.addAttribute("claimDto", dto);
        return "claims/submit-claim";
    }

    @PostMapping("/submit")
    public String submitClaim(@Valid @ModelAttribute("claimDto") ClaimRequestDto dto,
                              BindingResult bindingResult,
                              @AuthenticationPrincipal UserDetails userDetails,
                              Model model,
                              RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            FoundItem foundItem = foundItemService.getById(dto.getFoundItemId());
            model.addAttribute("foundItem", foundItem);
            return "claims/submit-claim";
        }

        User claimant = userService.findByEmail(userDetails.getUsername()).orElseThrow();

        try {
            claimService.submitClaim(dto, claimant);
            redirectAttributes.addFlashAttribute("successMessage",
                    "Your ownership claim has been submitted. Campus administrators will verify your details.");
            return "redirect:/claims/my";
        } catch (IllegalArgumentException | IllegalStateException ex) {
            redirectAttributes.addFlashAttribute("errorMessage", ex.getMessage());
            return "redirect:/found-items/" + dto.getFoundItemId();
        }
    }

    @GetMapping("/my")
    public String myClaims(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User claimant = userService.findByEmail(userDetails.getUsername()).orElseThrow();
        List<Claim> claims = claimService.getClaimsByUser(claimant);
        model.addAttribute("claims", claims);
        return "claims/my-claims";
    }

    @PostMapping("/review")
    public String reviewClaim(@Valid @ModelAttribute("reviewDto") ClaimReviewDto dto,
                              BindingResult bindingResult,
                              @AuthenticationPrincipal UserDetails userDetails,
                              RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("errorMessage", "Invalid review parameters submitted.");
            return "redirect:/admin/claims";
        }

        User reviewer = userService.findByEmail(userDetails.getUsername()).orElseThrow();
        claimService.reviewClaim(dto, reviewer);

        redirectAttributes.addFlashAttribute("successMessage",
                "Claim #" + dto.getClaimId() + " review status updated to " + dto.getStatus().getDisplayName());
        return "redirect:/admin/claims";
    }

    @PostMapping("/return/{claimId}")
    public String confirmHandover(@PathVariable("claimId") Long claimId,
                                  @AuthenticationPrincipal UserDetails userDetails,
                                  RedirectAttributes redirectAttributes) {
        User admin = userService.findByEmail(userDetails.getUsername()).orElseThrow();
        claimService.markItemAsReturned(claimId, admin);

        redirectAttributes.addFlashAttribute("successMessage",
                "Item handover successfully recorded! Item marked as RETURNED to rightful owner.");
        return "redirect:/admin/claims";
    }
}
