package com.lostfound.repository;

import com.lostfound.entity.LostItem;
import com.lostfound.entity.User;
import com.lostfound.enums.ItemCategory;
import com.lostfound.enums.LostItemStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface LostItemRepository extends JpaRepository<LostItem, Long> {

    List<LostItem> findByReporterOrderByCreatedAtDesc(User reporter);
    Page<LostItem> findByReporterOrderByCreatedAtDesc(User reporter, Pageable pageable);

    List<LostItem> findByStatus(LostItemStatus status);
    long countByStatus(LostItemStatus status);

    @Query("SELECT l FROM LostItem l WHERE " +
           "(:keyword IS NULL OR LOWER(l.title) LIKE LOWER(CONCAT('%', :keyword, '%')) OR LOWER(l.description) LIKE LOWER(CONCAT('%', :keyword, '%'))) AND " +
           "(:category IS NULL OR l.category = :category) AND " +
           "(:location IS NULL OR LOWER(l.lastKnownLocation) LIKE LOWER(CONCAT('%', :location, '%'))) AND " +
           "(:status IS NULL OR l.status = :status) AND " +
           "(:startDate IS NULL OR l.dateLost >= :startDate) AND " +
           "(:endDate IS NULL OR l.dateLost <= :endDate)")
    Page<LostItem> searchLostItems(@Param("keyword") String keyword,
                                   @Param("category") ItemCategory category,
                                   @Param("location") String location,
                                   @Param("status") LostItemStatus status,
                                   @Param("startDate") LocalDate startDate,
                                   @Param("endDate") LocalDate endDate,
                                   Pageable pageable);

    @Query("SELECT l.lastKnownLocation AS location, COUNT(l) AS cnt " +
           "FROM LostItem l GROUP BY l.lastKnownLocation ORDER BY cnt DESC")
    List<Object[]> findTopLocations(Pageable pageable);

    @Query("SELECT l.category, COUNT(l) FROM LostItem l GROUP BY l.category")
    List<Object[]> countGroupByCategory();
}
