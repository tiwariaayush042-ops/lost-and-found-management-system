package com.lostfound.repository;

import com.lostfound.entity.User;
import com.lostfound.enums.AccountStatus;
import com.lostfound.enums.Role;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);
    boolean existsByEmail(String email);
    long countByRole(Role role);
    long countByStatus(AccountStatus status);
    Page<User> findAllByOrderByCreatedAtDesc(Pageable pageable);
}
