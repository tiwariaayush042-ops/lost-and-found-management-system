package com.lostfound.repository;

import com.lostfound.entity.FoundItem;
import com.lostfound.entity.ItemMatch;
import com.lostfound.entity.LostItem;
import com.lostfound.enums.MatchStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ItemMatchRepository extends JpaRepository<ItemMatch, Long> {

    List<ItemMatch> findByLostItemAndStatusOrderByMatchScoreDesc(LostItem lostItem, MatchStatus status);

    List<ItemMatch> findByLostItemOrderByMatchScoreDesc(LostItem lostItem);

    List<ItemMatch> findByFoundItemOrderByMatchScoreDesc(FoundItem foundItem);

    boolean existsByLostItemIdAndFoundItemId(Long lostItemId, Long foundItemId);

    Optional<ItemMatch> findByLostItemIdAndFoundItemId(Long lostItemId, Long foundItemId);

    void deleteByLostItemId(Long lostItemId);

    void deleteByFoundItemId(Long foundItemId);
}
