package com.lostfound.repository;

import com.lostfound.entity.FoundItem;
import com.lostfound.entity.User;
import com.lostfound.enums.FoundItemStatus;
import com.lostfound.enums.ItemCategory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface FoundItemRepository extends JpaRepository<FoundItem, Long> {

    List<FoundItem> findByReporterOrderByCreatedAtDesc(User reporter);
    Page<FoundItem> findByReporterOrderByCreatedAtDesc(User reporter, Pageable pageable);

    List<FoundItem> findByStatus(FoundItemStatus status);
    long countByStatus(FoundItemStatus status);

    @Query("SELECT f FROM FoundItem f WHERE " +
           "(:keyword IS NULL OR LOWER(f.title) LIKE LOWER(CONCAT('%', :keyword, '%')) OR LOWER(f.description) LIKE LOWER(CONCAT('%', :keyword, '%'))) AND " +
           "(:category IS NULL OR f.category = :category) AND " +
           "(:location IS NULL OR LOWER(f.locationFound) LIKE LOWER(CONCAT('%', :location, '%'))) AND " +
           "(:status IS NULL OR f.status = :status) AND " +
           "(:startDate IS NULL OR f.dateFound >= :startDate) AND " +
           "(:endDate IS NULL OR f.dateFound <= :endDate)")
    Page<FoundItem> searchFoundItems(@Param("keyword") String keyword,
                                     @Param("category") ItemCategory category,
                                     @Param("location") String location,
                                     @Param("status") FoundItemStatus status,
                                     @Param("startDate") LocalDate startDate,
                                     @Param("endDate") LocalDate endDate,
                                     Pageable pageable);

    @Query("SELECT f.locationFound AS location, COUNT(f) AS cnt " +
           "FROM FoundItem f GROUP BY f.locationFound ORDER BY cnt DESC")
    List<Object[]> findTopLocations(Pageable pageable);

    @Query("SELECT f.category, COUNT(f) FROM FoundItem f GROUP BY f.category")
    List<Object[]> countGroupByCategory();
}
