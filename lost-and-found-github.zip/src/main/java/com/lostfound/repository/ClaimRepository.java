package com.lostfound.repository;

import com.lostfound.entity.Claim;
import com.lostfound.entity.FoundItem;
import com.lostfound.entity.User;
import com.lostfound.enums.ClaimStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ClaimRepository extends JpaRepository<Claim, Long> {

    List<Claim> findByClaimantOrderByCreatedAtDesc(User claimant);
    Page<Claim> findByClaimantOrderByCreatedAtDesc(User claimant, Pageable pageable);

    List<Claim> findByFoundItemOrderByCreatedAtDesc(FoundItem foundItem);

    List<Claim> findByStatusOrderByCreatedAtDesc(ClaimStatus status);
    Page<Claim> findByStatusOrderByCreatedAtDesc(ClaimStatus status, Pageable pageable);

    boolean existsByFoundItemIdAndClaimantIdAndStatus(Long foundItemId, Long claimantId, ClaimStatus status);

    long countByStatus(ClaimStatus status);

    Page<Claim> findAllByOrderByCreatedAtDesc(Pageable pageable);
}
