package com.lostfound.service;

import com.lostfound.dto.ClaimRequestDto;
import com.lostfound.dto.ClaimReviewDto;
import com.lostfound.entity.Claim;
import com.lostfound.entity.FoundItem;
import com.lostfound.entity.LostItem;
import com.lostfound.entity.User;
import com.lostfound.enums.*;
import com.lostfound.exception.ResourceNotFoundException;
import com.lostfound.exception.UnauthorizedActionException;
import com.lostfound.repository.ClaimRepository;
import com.lostfound.repository.FoundItemRepository;
import com.lostfound.repository.ItemMatchRepository;
import com.lostfound.repository.LostItemRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ClaimService {

    private final ClaimRepository claimRepository;
    private final FoundItemRepository foundItemRepository;
    private final LostItemRepository lostItemRepository;
    private final ItemMatchRepository itemMatchRepository;
    private final NotificationService notificationService;
    private final AuditLogService auditLogService;

    public ClaimService(ClaimRepository claimRepository,
                        FoundItemRepository foundItemRepository,
                        LostItemRepository lostItemRepository,
                        ItemMatchRepository itemMatchRepository,
                        NotificationService notificationService,
                        AuditLogService auditLogService) {
        this.claimRepository = claimRepository;
        this.foundItemRepository = foundItemRepository;
        this.lostItemRepository = lostItemRepository;
        this.itemMatchRepository = itemMatchRepository;
        this.notificationService = notificationService;
        this.auditLogService = auditLogService;
    }

    /**
     * Submit ownership claim for a found item.
     */
    @Transactional
    public Claim submitClaim(ClaimRequestDto dto, User claimant) {
        FoundItem foundItem = foundItemRepository.findById(dto.getFoundItemId())
                .orElseThrow(() -> new ResourceNotFoundException("Found item not found with ID: " + dto.getFoundItemId()));

        // Cannot claim an item you reported found yourself
        if (foundItem.getReporter().getId().equals(claimant.getId())) {
            throw new IllegalArgumentException("You cannot submit an ownership claim for an item you reported as found.");
        }

        // Cannot claim already returned or withdrawn items
        if (foundItem.getStatus() == FoundItemStatus.RETURNED || foundItem.getStatus() == FoundItemStatus.WITHDRAWN) {
            throw new IllegalStateException("This item has already been returned or withdrawn and is no longer open for claims.");
        }

        // Check for duplicate pending claim by this user
        boolean hasPending = claimRepository.existsByFoundItemIdAndClaimantIdAndStatus(
                foundItem.getId(), claimant.getId(), ClaimStatus.PENDING);
        if (hasPending) {
            throw new IllegalArgumentException("You already have an active pending claim for this item.");
        }

        Claim claim = new Claim(foundItem, claimant, dto.getEvidenceDescription().trim());
        Claim savedClaim = claimRepository.save(claim);

        // Update found item status to UNDER_CLAIM if currently AVAILABLE
        if (foundItem.getStatus() == FoundItemStatus.AVAILABLE) {
            foundItem.setStatus(FoundItemStatus.UNDER_CLAIM);
            foundItemRepository.save(foundItem);
        }

        // Notify claimant
        notificationService.sendNotification(
                claimant,
                "Claim Submitted",
                "Your ownership claim for \"" + foundItem.getTitle() + "\" has been received and is pending administrator verification.",
                NotificationType.CLAIM_UPDATE,
                "/claims/my"
        );

        // Notify finder
        notificationService.sendNotification(
                foundItem.getReporter(),
                "New Claim on Found Item",
                "A campus member submitted an ownership claim for \"" + foundItem.getTitle() + "\". Administrators are reviewing the request.",
                NotificationType.CLAIM_UPDATE,
                "/found-items/" + foundItem.getId()
        );

        auditLogService.log(claimant.getEmail(), claimant.getRole().name(), "CLAIM_SUBMITTED",
                "Claim", savedClaim.getId(), "Submitted ownership claim for item: " + foundItem.getTitle());

        return savedClaim;
    }

    /**
     * Review ownership claim (Approve or Reject with reason).
     */
    @Transactional
    public Claim reviewClaim(ClaimReviewDto dto, User reviewer) {
        Claim claim = claimRepository.findById(dto.getClaimId())
                .orElseThrow(() -> new ResourceNotFoundException("Claim not found with ID: " + dto.getClaimId()));

        if (reviewer.getRole() != Role.ROLE_ADMIN && reviewer.getRole() != Role.ROLE_STAFF) {
            throw new UnauthorizedActionException("Only administrators or authorized staff can review ownership claims.");
        }

        if (claim.getClaimant().getId().equals(reviewer.getId())) {
            throw new UnauthorizedActionException("You cannot approve or reject your own ownership claim.");
        }

        if (claim.getStatus() != ClaimStatus.PENDING) {
            throw new IllegalStateException("Only pending claims can be reviewed.");
        }

        claim.setStatus(dto.getStatus());
        claim.setAdminNotes(dto.getAdminNotes() != null ? dto.getAdminNotes().trim() : "");
        claim.setReviewer(reviewer);
        claim.setReviewedAt(LocalDateTime.now());

        FoundItem item = claim.getFoundItem();

        if (dto.getStatus() == ClaimStatus.APPROVED) {
            item.setStatus(FoundItemStatus.CLAIMED);
            foundItemRepository.save(item);

            notificationService.sendNotification(
                    claim.getClaimant(),
                    "Claim Approved! Collect Your Item",
                    "Your claim for \"" + item.getTitle() + "\" has been approved! Please visit the Campus Lost & Found Desk to collect your item.",
                    NotificationType.CLAIM_UPDATE,
                    "/claims/my"
            );
        } else if (dto.getStatus() == ClaimStatus.REJECTED) {
            // Check if there are other pending or approved claims
            List<Claim> otherClaims = claimRepository.findByFoundItemOrderByCreatedAtDesc(item);
            boolean hasOtherActive = otherClaims.stream()
                    .anyMatch(c -> !c.getId().equals(claim.getId()) &&
                            (c.getStatus() == ClaimStatus.PENDING || c.getStatus() == ClaimStatus.APPROVED));

            if (!hasOtherActive) {
                item.setStatus(FoundItemStatus.AVAILABLE);
                foundItemRepository.save(item);
            }

            notificationService.sendNotification(
                    claim.getClaimant(),
                    "Claim Rejected",
                    "Your claim for \"" + item.getTitle() + "\" was not approved. Admin notes: " + claim.getAdminNotes(),
                    NotificationType.CLAIM_UPDATE,
                    "/claims/my"
            );
        }

        Claim updated = claimRepository.save(claim);

        auditLogService.log(reviewer.getEmail(), reviewer.getRole().name(), "CLAIM_REVIEWED",
                "Claim", updated.getId(), "Claim #" + updated.getId() + " was " + dto.getStatus().name() + " by " + reviewer.getFullName());

        return updated;
    }

    /**
     * Mark item as physically returned to owner.
     */
    @Transactional
    public void markItemAsReturned(Long claimId, User administrator) {
        if (administrator.getRole() != Role.ROLE_ADMIN) {
            throw new UnauthorizedActionException("Only administrators can confirm physical return of items.");
        }

        Claim claim = claimRepository.findById(claimId)
                .orElseThrow(() -> new ResourceNotFoundException("Claim not found with ID: " + claimId));

        if (claim.getStatus() != ClaimStatus.APPROVED) {
            throw new IllegalStateException("Only claims with APPROVED status can proceed to physical return handover.");
        }

        claim.setStatus(ClaimStatus.RETURNED);
        claimRepository.save(claim);

        FoundItem foundItem = claim.getFoundItem();
        foundItem.setStatus(FoundItemStatus.RETURNED);
        foundItemRepository.save(foundItem);

        // Check if claimant had a matching lost item and resolve it
        List<LostItem> claimantLostReports = lostItemRepository.findByReporterOrderByCreatedAtDesc(claim.getClaimant());
        for (LostItem lost : claimantLostReports) {
            if (lost.getStatus() == LostItemStatus.LOST && lost.getCategory().equals(foundItem.getCategory())) {
                lost.setStatus(LostItemStatus.RESOLVED);
                lostItemRepository.save(lost);
                break;
            }
        }

        // Notify both parties
        notificationService.sendNotification(
                claim.getClaimant(),
                "Item Returned Successfully",
                "Physical handover of \"" + foundItem.getTitle() + "\" has been confirmed. Thank you for using CampusFind!",
                NotificationType.ITEM_STATUS,
                "/claims/my"
        );

        notificationService.sendNotification(
                foundItem.getReporter(),
                "Found Item Returned to Owner",
                "The item \"" + foundItem.getTitle() + "\" you kindly handed in has been successfully returned to its rightful owner. Thank you for your honesty!",
                NotificationType.ITEM_STATUS,
                "/found-items/" + foundItem.getId()
        );

        auditLogService.log(administrator.getEmail(), administrator.getRole().name(), "ITEM_RETURNED",
                "FoundItem", foundItem.getId(), "Physical handover verified and item marked as RETURNED for Claim #" + claim.getId());
    }

    public Claim getById(Long id) {
        return claimRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Claim not found with ID: " + id));
    }

    public List<Claim> getClaimsByUser(User user) {
        return claimRepository.findByClaimantOrderByCreatedAtDesc(user);
    }

    public Page<Claim> getAllClaims(Pageable pageable) {
        return claimRepository.findAllByOrderByCreatedAtDesc(pageable);
    }

    public Page<Claim> getClaimsByStatus(ClaimStatus status, Pageable pageable) {
        return claimRepository.findByStatusOrderByCreatedAtDesc(status, pageable);
    }

    public long getPendingClaimsCount() {
        return claimRepository.countByStatus(ClaimStatus.PENDING);
    }
}
