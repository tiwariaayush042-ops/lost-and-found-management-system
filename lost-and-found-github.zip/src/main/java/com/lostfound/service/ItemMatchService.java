package com.lostfound.service;

import com.lostfound.entity.FoundItem;
import com.lostfound.entity.ItemMatch;
import com.lostfound.entity.LostItem;
import com.lostfound.enums.FoundItemStatus;
import com.lostfound.enums.LostItemStatus;
import com.lostfound.enums.MatchStatus;
import com.lostfound.enums.NotificationType;
import com.lostfound.repository.FoundItemRepository;
import com.lostfound.repository.ItemMatchRepository;
import com.lostfound.repository.LostItemRepository;
import com.lostfound.util.DateUtil;
import com.lostfound.util.TextSimilarityUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
public class ItemMatchService {

    private static final Logger logger = LoggerFactory.getLogger(ItemMatchService.class);

    private final ItemMatchRepository itemMatchRepository;
    private final LostItemRepository lostItemRepository;
    private final FoundItemRepository foundItemRepository;
    private final NotificationService notificationService;

    @Value("${lostfound.matching.weight.category:25}")
    private int categoryWeight;

    @Value("${lostfound.matching.weight.name:25}")
    private int nameWeight;

    @Value("${lostfound.matching.weight.location:20}")
    private int locationWeight;

    @Value("${lostfound.matching.weight.date:15}")
    private int dateWeight;

    @Value("${lostfound.matching.weight.description:15}")
    private int descriptionWeight;

    @Value("${lostfound.matching.threshold:35}")
    private int matchThreshold;

    public ItemMatchService(ItemMatchRepository itemMatchRepository,
                            LostItemRepository lostItemRepository,
                            FoundItemRepository foundItemRepository,
                            NotificationService notificationService) {
        this.itemMatchRepository = itemMatchRepository;
        this.lostItemRepository = lostItemRepository;
        this.foundItemRepository = foundItemRepository;
        this.notificationService = notificationService;
    }

    public static class MatchCalculationResult {
        private final int totalScore;
        private final String explanation;

        public MatchCalculationResult(int totalScore, String explanation) {
            this.totalScore = totalScore;
            this.explanation = explanation;
        }

        public int getTotalScore() {
            return totalScore;
        }

        public String getExplanation() {
            return explanation;
        }
    }

    /**
     * Computes the deterministic, transparent rule-based score between a lost and found item.
     */
    public MatchCalculationResult calculateScore(LostItem lost, FoundItem found) {
        List<String> criteriaMatched = new ArrayList<>();
        double accumulatedScore = 0.0;

        // 1. Category Similarity (25 points)
        if (lost.getCategory() != null && lost.getCategory().equals(found.getCategory())) {
            accumulatedScore += categoryWeight;
            criteriaMatched.add("Identical category: " + lost.getCategory().getDisplayName());
        }

        // 2. Name / Title Similarity (up to 25 points)
        double nameSim = TextSimilarityUtil.computeNameSimilarity(lost.getTitle(), found.getTitle());
        if (nameSim > 0.20) {
            double pts = nameSim * nameWeight;
            accumulatedScore += pts;
            criteriaMatched.add(String.format("Title similarity (%.0f%%)", nameSim * 100));
        }

        // 3. Location Similarity (up to 20 points)
        double locSim = TextSimilarityUtil.computeLocationSimilarity(lost.getLastKnownLocation(), found.getLocationFound());
        if (locSim > 0.25) {
            double pts = locSim * locationWeight;
            accumulatedScore += pts;
            criteriaMatched.add(String.format("Location proximity (%.0f%%)", locSim * 100));
        }

        // 4. Date Proximity (up to 15 points)
        double dateSim = DateUtil.computeDateProximity(lost.getDateLost(), found.getDateFound());
        if (dateSim > 0.0) {
            double pts = dateSim * dateWeight;
            accumulatedScore += pts;
            criteriaMatched.add(String.format("Date proximity (%.0f%%)", dateSim * 100));
        }

        // 5. Description Keyword Overlap (up to 15 points)
        Set<String> lostDescTokens = TextSimilarityUtil.extractMeaningfulTokens(lost.getDescription());
        Set<String> foundDescTokens = TextSimilarityUtil.extractMeaningfulTokens(found.getDescription());
        double descSim = TextSimilarityUtil.jaccardSimilarity(lostDescTokens, foundDescTokens);
        if (descSim > 0.15) {
            double pts = descSim * descriptionWeight;
            accumulatedScore += pts;
            criteriaMatched.add(String.format("Description keyword overlap (%.0f%%)", descSim * 100));
        }

        int finalScore = (int) Math.min(100, Math.round(accumulatedScore));
        String explanation = criteriaMatched.isEmpty() ?
                "Low correlation across category, title and location." :
                String.join("; ", criteriaMatched) + ".";

        return new MatchCalculationResult(finalScore, explanation);
    }

    /**
     * Executes matching when a new or edited LostItem is saved.
     */
    @Transactional
    public void runMatchingForLostItem(LostItem lostItem) {
        if (lostItem.getStatus() != LostItemStatus.LOST) {
            return;
        }

        List<FoundItem> availableFound = foundItemRepository.findByStatus(FoundItemStatus.AVAILABLE);
        for (FoundItem found : availableFound) {
            // Cannot match items reported by the same user if they are identical
            if (lostItem.getReporter().getId().equals(found.getReporter().getId())) {
                continue;
            }

            MatchCalculationResult result = calculateScore(lostItem, found);
            if (result.getTotalScore() >= matchThreshold) {
                saveOrUpdateMatch(lostItem, found, result);
            }
        }
    }

    /**
     * Executes matching when a new or edited FoundItem is saved.
     */
    @Transactional
    public void runMatchingForFoundItem(FoundItem foundItem) {
        if (foundItem.getStatus() != FoundItemStatus.AVAILABLE) {
            return;
        }

        List<LostItem> activeLost = lostItemRepository.findByStatus(LostItemStatus.LOST);
        for (LostItem lost : activeLost) {
            if (lost.getReporter().getId().equals(foundItem.getReporter().getId())) {
                continue;
            }

            MatchCalculationResult result = calculateScore(lost, foundItem);
            if (result.getTotalScore() >= matchThreshold) {
                saveOrUpdateMatch(lost, foundItem, result);
            }
        }
    }

    private void saveOrUpdateMatch(LostItem lost, FoundItem found, MatchCalculationResult result) {
        Optional<ItemMatch> existingOpt = itemMatchRepository.findByLostItemIdAndFoundItemId(lost.getId(), found.getId());
        if (existingOpt.isPresent()) {
            ItemMatch match = existingOpt.get();
            match.setMatchScore(result.getTotalScore());
            match.setMatchExplanation(result.getExplanation());
            itemMatchRepository.save(match);
        } else {
            ItemMatch match = new ItemMatch(lost, found, result.getTotalScore(), result.getExplanation());
            itemMatchRepository.save(match);

            // Notify lost item owner of potential match if score is confident (>= 50)
            if (result.getTotalScore() >= 50) {
                notificationService.sendNotification(
                        lost.getReporter(),
                        "Potential Match Found: " + found.getTitle(),
                        "A newly registered found item (" + found.getTitle() + ") matches your lost report with a score of " +
                                result.getTotalScore() + "/100.",
                        NotificationType.MATCH_FOUND,
                        "/matches/lost/" + lost.getId()
                );
            }
        }
    }

    public List<ItemMatch> getMatchesForLostItem(LostItem lostItem) {
        return itemMatchRepository.findByLostItemOrderByMatchScoreDesc(lostItem);
    }

    public List<ItemMatch> getMatchesForFoundItem(FoundItem foundItem) {
        return itemMatchRepository.findByFoundItemOrderByMatchScoreDesc(foundItem);
    }
}
