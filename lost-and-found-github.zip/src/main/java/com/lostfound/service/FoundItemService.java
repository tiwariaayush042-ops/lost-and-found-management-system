package com.lostfound.service;

import com.lostfound.dto.FoundItemDto;
import com.lostfound.dto.ItemSearchCriteria;
import com.lostfound.entity.FoundItem;
import com.lostfound.entity.User;
import com.lostfound.enums.FoundItemStatus;
import com.lostfound.enums.Role;
import com.lostfound.exception.ResourceNotFoundException;
import com.lostfound.exception.UnauthorizedActionException;
import com.lostfound.repository.FoundItemRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class FoundItemService {

    private final FoundItemRepository foundItemRepository;
    private final FileStorageService fileStorageService;
    private final ItemMatchService itemMatchService;
    private final AuditLogService auditLogService;

    public FoundItemService(FoundItemRepository foundItemRepository,
                            FileStorageService fileStorageService,
                            ItemMatchService itemMatchService,
                            AuditLogService auditLogService) {
        this.foundItemRepository = foundItemRepository;
        this.fileStorageService = fileStorageService;
        this.itemMatchService = itemMatchService;
        this.auditLogService = auditLogService;
    }

    @Transactional
    public FoundItem createFoundItem(FoundItemDto dto, User reporter) {
        String savedImage = null;
        if (dto.getImage() != null && !dto.getImage().isEmpty()) {
            savedImage = fileStorageService.storeFile(dto.getImage());
        }

        FoundItem item = new FoundItem(
                reporter,
                dto.getTitle().trim(),
                dto.getCategory(),
                dto.getDescription().trim(),
                dto.getLocationFound().trim(),
                dto.getDateFound(),
                dto.getTimeFoundApprox() != null ? dto.getTimeFoundApprox().trim() : null,
                savedImage
        );

        FoundItem saved = foundItemRepository.save(item);

        auditLogService.log(reporter.getEmail(), reporter.getRole().name(), "FOUND_ITEM_REPORTED",
                "FoundItem", saved.getId(), "Reported found item: " + saved.getTitle());

        // Run smart matching against active lost items
        itemMatchService.runMatchingForFoundItem(saved);

        return saved;
    }

    @Transactional
    public FoundItem updateFoundItem(Long id, FoundItemDto dto, User currentUser) {
        FoundItem item = getById(id);

        boolean isOwner = item.getReporter().getId().equals(currentUser.getId());
        boolean isAdmin = currentUser.getRole() == Role.ROLE_ADMIN;

        if (!isOwner && !isAdmin) {
            throw new UnauthorizedActionException("You are not authorized to edit this found item report.");
        }

        if (item.getStatus() == FoundItemStatus.RETURNED || item.getStatus() == FoundItemStatus.WITHDRAWN) {
            throw new IllegalStateException("Returned or withdrawn reports cannot be modified.");
        }

        item.setTitle(dto.getTitle().trim());
        item.setCategory(dto.getCategory());
        item.setDescription(dto.getDescription().trim());
        item.setLocationFound(dto.getLocationFound().trim());
        item.setDateFound(dto.getDateFound());
        item.setTimeFoundApprox(dto.getTimeFoundApprox());

        if (dto.getImage() != null && !dto.getImage().isEmpty()) {
            if (item.getImagePath() != null) {
                fileStorageService.deleteFile(item.getImagePath());
            }
            String newImage = fileStorageService.storeFile(dto.getImage());
            item.setImagePath(newImage);
        }

        FoundItem updated = foundItemRepository.save(item);

        auditLogService.log(currentUser.getEmail(), currentUser.getRole().name(), "FOUND_ITEM_UPDATED",
                "FoundItem", updated.getId(), "Updated found item: " + updated.getTitle());

        itemMatchService.runMatchingForFoundItem(updated);

        return updated;
    }

    @Transactional
    public void withdrawFoundItem(Long id, User currentUser) {
        FoundItem item = getById(id);

        boolean isOwner = item.getReporter().getId().equals(currentUser.getId());
        boolean isAdmin = currentUser.getRole() == Role.ROLE_ADMIN;

        if (!isOwner && !isAdmin) {
            throw new UnauthorizedActionException("You are not authorized to withdraw this report.");
        }

        item.setStatus(FoundItemStatus.WITHDRAWN);
        foundItemRepository.save(item);

        auditLogService.log(currentUser.getEmail(), currentUser.getRole().name(), "FOUND_ITEM_WITHDRAWN",
                "FoundItem", item.getId(), "Withdrew found report: " + item.getTitle());
    }

    public FoundItem getById(Long id) {
        return foundItemRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Found item report not found with ID: " + id));
    }

    public List<FoundItem> getReportsByUser(User user) {
        return foundItemRepository.findByReporterOrderByCreatedAtDesc(user);
    }

    public Page<FoundItem> search(ItemSearchCriteria criteria) {
        Sort sort = "oldest".equalsIgnoreCase(criteria.getSortBy()) ?
                Sort.by("createdAt").ascending() : Sort.by("createdAt").descending();

        Pageable pageable = PageRequest.of(criteria.getPage(), criteria.getSize(), sort);

        String keyword = (criteria.getKeyword() != null && !criteria.getKeyword().isBlank()) ?
                criteria.getKeyword().trim() : null;
        String location = (criteria.getLocation() != null && !criteria.getLocation().isBlank()) ?
                criteria.getLocation().trim() : null;

        FoundItemStatus statusEnum = null;
        if (criteria.getStatus() != null && !criteria.getStatus().isBlank()) {
            try {
                statusEnum = FoundItemStatus.valueOf(criteria.getStatus());
            } catch (IllegalArgumentException ignored) {
            }
        }

        return foundItemRepository.searchFoundItems(
                keyword,
                criteria.getCategory(),
                location,
                statusEnum,
                criteria.getStartDate(),
                criteria.getEndDate(),
                pageable
        );
    }

    public long getAvailableFoundCount() {
        return foundItemRepository.countByStatus(FoundItemStatus.AVAILABLE);
    }

    public long getReturnedFoundCount() {
        return foundItemRepository.countByStatus(FoundItemStatus.RETURNED);
    }
}
