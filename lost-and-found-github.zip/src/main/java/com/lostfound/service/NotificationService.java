package com.lostfound.service;

import com.lostfound.entity.Notification;
import com.lostfound.entity.User;
import com.lostfound.enums.NotificationType;
import com.lostfound.repository.NotificationRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class NotificationService {

    private final NotificationRepository notificationRepository;

    public NotificationService(NotificationRepository notificationRepository) {
        this.notificationRepository = notificationRepository;
    }

    @Transactional
    public Notification sendNotification(User recipient, String title, String message,
                                        NotificationType type, String linkUrl) {
        Notification notification = new Notification(recipient, title, message, type, linkUrl);
        return notificationRepository.save(notification);
    }

    public List<Notification> getUserNotifications(User recipient) {
        return notificationRepository.findByRecipientOrderByCreatedAtDesc(recipient);
    }

    public Page<Notification> getUserNotifications(User recipient, Pageable pageable) {
        return notificationRepository.findByRecipientOrderByCreatedAtDesc(recipient, pageable);
    }

    public long getUnreadCount(User recipient) {
        return notificationRepository.countByRecipientAndReadStatusFalse(recipient);
    }

    @Transactional
    public void markAsRead(Long notificationId, User user) {
        notificationRepository.findById(notificationId).ifPresent(notif -> {
            if (notif.getRecipient().getId().equals(user.getId())) {
                notif.setReadStatus(true);
                notificationRepository.save(notif);
            }
        });
    }

    @Transactional
    public void markAllAsRead(User recipient) {
        List<Notification> unread = notificationRepository.findByRecipientOrderByCreatedAtDesc(recipient);
        for (Notification n : unread) {
            if (!n.isReadStatus()) {
                n.setReadStatus(true);
            }
        }
        notificationRepository.saveAll(unread);
    }
}
