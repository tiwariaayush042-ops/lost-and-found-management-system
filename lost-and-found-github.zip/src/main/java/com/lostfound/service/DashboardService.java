package com.lostfound.service;

import com.lostfound.dto.DashboardStatsDto;
import com.lostfound.enums.ClaimStatus;
import com.lostfound.enums.FoundItemStatus;
import com.lostfound.enums.ItemCategory;
import com.lostfound.enums.LostItemStatus;
import com.lostfound.repository.ClaimRepository;
import com.lostfound.repository.FoundItemRepository;
import com.lostfound.repository.LostItemRepository;
import com.lostfound.repository.UserRepository;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class DashboardService {

    private final LostItemRepository lostItemRepository;
    private final FoundItemRepository foundItemRepository;
    private final ClaimRepository claimRepository;
    private final UserRepository userRepository;

    public DashboardService(LostItemRepository lostItemRepository,
                            FoundItemRepository foundItemRepository,
                            ClaimRepository claimRepository,
                            UserRepository userRepository) {
        this.lostItemRepository = lostItemRepository;
        this.foundItemRepository = foundItemRepository;
        this.claimRepository = claimRepository;
        this.userRepository = userRepository;
    }

    public DashboardStatsDto getDashboardStatistics() {
        DashboardStatsDto stats = new DashboardStatsDto();

        long activeLost = lostItemRepository.countByStatus(LostItemStatus.LOST);
        long availableFound = foundItemRepository.countByStatus(FoundItemStatus.AVAILABLE);
        long returnedFound = foundItemRepository.countByStatus(FoundItemStatus.RETURNED);
        long pendingClaims = claimRepository.countByStatus(ClaimStatus.PENDING);
        long totalUsers = userRepository.count();

        stats.setActiveLostCount(activeLost);
        stats.setAvailableFoundCount(availableFound);
        stats.setReturnedCount(returnedFound);
        stats.setPendingClaimsCount(pendingClaims);
        stats.setTotalUsersCount(totalUsers);

        // Safe recovery rate calculation: (returned / (activeLost + availableFound + returned)) * 100
        long totalItemsReported = activeLost + availableFound + returnedFound;
        double recoveryRate = 0.0;
        if (totalItemsReported > 0) {
            recoveryRate = ((double) returnedFound / totalItemsReported) * 100.0;
        }
        stats.setRecoveryRate(Math.round(recoveryRate * 10.0) / 10.0);

        // Compute top reported campus locations
        Map<String, Long> locationMap = new HashMap<>();
        List<Object[]> topLostLocs = lostItemRepository.findTopLocations(PageRequest.of(0, 10));
        for (Object[] row : topLostLocs) {
            String loc = (String) row[0];
            Long cnt = (Long) row[1];
            if (loc != null && !loc.isBlank()) {
                locationMap.put(loc.trim(), locationMap.getOrDefault(loc.trim(), 0L) + cnt);
            }
        }
        List<Object[]> topFoundLocs = foundItemRepository.findTopLocations(PageRequest.of(0, 10));
        for (Object[] row : topFoundLocs) {
            String loc = (String) row[0];
            Long cnt = (Long) row[1];
            if (loc != null && !loc.isBlank()) {
                locationMap.put(loc.trim(), locationMap.getOrDefault(loc.trim(), 0L) + cnt);
            }
        }

        List<DashboardStatsDto.LocationStat> locationStats = new ArrayList<>();
        locationMap.entrySet().stream()
                .sorted((e1, e2) -> Long.compare(e2.getValue(), e1.getValue()))
                .limit(5)
                .forEach(e -> locationStats.add(new DashboardStatsDto.LocationStat(e.getKey(), e.getValue())));
        stats.setTopLocations(locationStats);

        // Category breakdown
        Map<String, Long> catDist = new LinkedHashMap<>();
        for (ItemCategory cat : ItemCategory.values()) {
            catDist.put(cat.getDisplayName(), 0L);
        }

        List<Object[]> lostCats = lostItemRepository.countGroupByCategory();
        for (Object[] row : lostCats) {
            ItemCategory c = (ItemCategory) row[0];
            Long cnt = (Long) row[1];
            if (c != null) {
                catDist.put(c.getDisplayName(), catDist.getOrDefault(c.getDisplayName(), 0L) + cnt);
            }
        }

        List<Object[]> foundCats = foundItemRepository.countGroupByCategory();
        for (Object[] row : foundCats) {
            ItemCategory c = (ItemCategory) row[0];
            Long cnt = (Long) row[1];
            if (c != null) {
                catDist.put(c.getDisplayName(), catDist.getOrDefault(c.getDisplayName(), 0L) + cnt);
            }
        }
        stats.setCategoryDistribution(catDist);

        return stats;
    }
}
