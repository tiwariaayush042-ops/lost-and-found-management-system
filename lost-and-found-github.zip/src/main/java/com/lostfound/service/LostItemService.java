package com.lostfound.service;

import com.lostfound.dto.ItemSearchCriteria;
import com.lostfound.dto.LostItemDto;
import com.lostfound.entity.LostItem;
import com.lostfound.entity.User;
import com.lostfound.enums.LostItemStatus;
import com.lostfound.enums.Role;
import com.lostfound.exception.ResourceNotFoundException;
import com.lostfound.exception.UnauthorizedActionException;
import com.lostfound.repository.LostItemRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class LostItemService {

    private final LostItemRepository lostItemRepository;
    private final FileStorageService fileStorageService;
    private final ItemMatchService itemMatchService;
    private final AuditLogService auditLogService;

    public LostItemService(LostItemRepository lostItemRepository,
                           FileStorageService fileStorageService,
                           ItemMatchService itemMatchService,
                           AuditLogService auditLogService) {
        this.lostItemRepository = lostItemRepository;
        this.fileStorageService = fileStorageService;
        this.itemMatchService = itemMatchService;
        this.auditLogService = auditLogService;
    }

    @Transactional
    public LostItem createLostItem(LostItemDto dto, User reporter) {
        String savedImage = null;
        if (dto.getImage() != null && !dto.getImage().isEmpty()) {
            savedImage = fileStorageService.storeFile(dto.getImage());
        }

        LostItem item = new LostItem(
                reporter,
                dto.getTitle().trim(),
                dto.getCategory(),
                dto.getDescription().trim(),
                dto.getLastKnownLocation().trim(),
                dto.getDateLost(),
                dto.getTimeLostApprox() != null ? dto.getTimeLostApprox().trim() : null,
                savedImage
        );

        LostItem saved = lostItemRepository.save(item);

        auditLogService.log(reporter.getEmail(), reporter.getRole().name(), "LOST_ITEM_REPORTED",
                "LostItem", saved.getId(), "Reported lost item: " + saved.getTitle());

        // Run smart matching against available found items
        itemMatchService.runMatchingForLostItem(saved);

        return saved;
    }

    @Transactional
    public LostItem updateLostItem(Long id, LostItemDto dto, User currentUser) {
        LostItem item = getById(id);

        boolean isOwner = item.getReporter().getId().equals(currentUser.getId());
        boolean isAdmin = currentUser.getRole() == Role.ROLE_ADMIN;

        if (!isOwner && !isAdmin) {
            throw new UnauthorizedActionException("You are not authorized to edit this lost item report.");
        }

        if (item.getStatus() == LostItemStatus.RESOLVED || item.getStatus() == LostItemStatus.WITHDRAWN) {
            throw new IllegalStateException("Resolved or withdrawn reports cannot be modified.");
        }

        item.setTitle(dto.getTitle().trim());
        item.setCategory(dto.getCategory());
        item.setDescription(dto.getDescription().trim());
        item.setLastKnownLocation(dto.getLastKnownLocation().trim());
        item.setDateLost(dto.getDateLost());
        item.setTimeLostApprox(dto.getTimeLostApprox());

        if (dto.getImage() != null && !dto.getImage().isEmpty()) {
            if (item.getImagePath() != null) {
                fileStorageService.deleteFile(item.getImagePath());
            }
            String newImage = fileStorageService.storeFile(dto.getImage());
            item.setImagePath(newImage);
        }

        LostItem updated = lostItemRepository.save(item);

        auditLogService.log(currentUser.getEmail(), currentUser.getRole().name(), "LOST_ITEM_UPDATED",
                "LostItem", updated.getId(), "Updated lost item: " + updated.getTitle());

        itemMatchService.runMatchingForLostItem(updated);

        return updated;
    }

    @Transactional
    public void withdrawLostItem(Long id, User currentUser) {
        LostItem item = getById(id);

        boolean isOwner = item.getReporter().getId().equals(currentUser.getId());
        boolean isAdmin = currentUser.getRole() == Role.ROLE_ADMIN;

        if (!isOwner && !isAdmin) {
            throw new UnauthorizedActionException("You are not authorized to withdraw this report.");
        }

        item.setStatus(LostItemStatus.WITHDRAWN);
        lostItemRepository.save(item);

        auditLogService.log(currentUser.getEmail(), currentUser.getRole().name(), "LOST_ITEM_WITHDRAWN",
                "LostItem", item.getId(), "Withdrew lost report: " + item.getTitle());
    }

    public LostItem getById(Long id) {
        return lostItemRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Lost item report not found with ID: " + id));
    }

    public List<LostItem> getReportsByUser(User user) {
        return lostItemRepository.findByReporterOrderByCreatedAtDesc(user);
    }

    public Page<LostItem> search(ItemSearchCriteria criteria) {
        Sort sort = "oldest".equalsIgnoreCase(criteria.getSortBy()) ?
                Sort.by("createdAt").ascending() : Sort.by("createdAt").descending();

        Pageable pageable = PageRequest.of(criteria.getPage(), criteria.getSize(), sort);

        String keyword = (criteria.getKeyword() != null && !criteria.getKeyword().isBlank()) ?
                criteria.getKeyword().trim() : null;
        String location = (criteria.getLocation() != null && !criteria.getLocation().isBlank()) ?
                criteria.getLocation().trim() : null;

        LostItemStatus statusEnum = null;
        if (criteria.getStatus() != null && !criteria.getStatus().isBlank()) {
            try {
                statusEnum = LostItemStatus.valueOf(criteria.getStatus());
            } catch (IllegalArgumentException ignored) {
            }
        }

        return lostItemRepository.searchLostItems(
                keyword,
                criteria.getCategory(),
                location,
                statusEnum,
                criteria.getStartDate(),
                criteria.getEndDate(),
                pageable
        );
    }

    public long getActiveLostCount() {
        return lostItemRepository.countByStatus(LostItemStatus.LOST);
    }
}
