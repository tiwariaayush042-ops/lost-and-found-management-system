package com.lostfound.service;

import com.lostfound.dto.UserRegistrationDto;
import com.lostfound.entity.User;
import com.lostfound.enums.AccountStatus;
import com.lostfound.enums.Role;
import com.lostfound.exception.ResourceNotFoundException;
import com.lostfound.exception.UnauthorizedActionException;
import com.lostfound.repository.UserRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuditLogService auditLogService;

    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder, AuditLogService auditLogService) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.auditLogService = auditLogService;
    }

    @Transactional
    public User registerUser(UserRegistrationDto dto) {
        if (userRepository.existsByEmail(dto.getEmail())) {
            throw new IllegalArgumentException("An account with email " + dto.getEmail() + " already exists.");
        }

        if (!dto.getPassword().equals(dto.getConfirmPassword())) {
            throw new IllegalArgumentException("Password and confirm password do not match.");
        }

        // Default role is STUDENT unless explicitly selected as STAFF. ADMIN registration cannot be requested via public form.
        Role assignedRole = (dto.getRole() == Role.ROLE_STAFF) ? Role.ROLE_STAFF : Role.ROLE_STUDENT;

        User user = new User(
                dto.getFullName().trim(),
                dto.getEmail().trim().toLowerCase(),
                passwordEncoder.encode(dto.getPassword()),
                assignedRole,
                dto.getIdentifier() != null ? dto.getIdentifier().trim() : null
        );

        User savedUser = userRepository.save(user);
        auditLogService.log(savedUser.getEmail(), savedUser.getRole().name(), "USER_REGISTERED", "User", savedUser.getId(),
                "New user registered: " + savedUser.getFullName() + " (" + savedUser.getRole().getDisplayName() + ")");
        return savedUser;
    }

    public Optional<User> findByEmail(String email) {
        return userRepository.findByEmail(email.toLowerCase().trim());
    }

    public User getById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with ID: " + id));
    }

    public Page<User> getAllUsers(Pageable pageable) {
        return userRepository.findAllByOrderByCreatedAtDesc(pageable);
    }

    @Transactional
    public void updateUserStatus(Long userId, AccountStatus status, String adminEmail) {
        User user = getById(userId);
        if (user.getEmail().equalsIgnoreCase(adminEmail)) {
            throw new UnauthorizedActionException("Administrators cannot change their own account status.");
        }
        user.setStatus(status);
        userRepository.save(user);
        auditLogService.log(adminEmail, "ROLE_ADMIN", "USER_STATUS_UPDATED", "User", user.getId(),
                "User " + user.getEmail() + " status updated to " + status.name());
    }

    @Transactional
    public void updateUserRole(Long userId, Role newRole, String adminEmail) {
        User user = getById(userId);
        if (user.getEmail().equalsIgnoreCase(adminEmail)) {
            throw new UnauthorizedActionException("Administrators cannot change their own role.");
        }
        user.setRole(newRole);
        userRepository.save(user);
        auditLogService.log(adminEmail, "ROLE_ADMIN", "USER_ROLE_UPDATED", "User", user.getId(),
                "User " + user.getEmail() + " role changed to " + newRole.name());
    }

    public long getTotalUserCount() {
        return userRepository.count();
    }
}
