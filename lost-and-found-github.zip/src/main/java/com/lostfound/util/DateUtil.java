package com.lostfound.util;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class DateUtil {

    /**
     * Computes proximity score between two dates (0.0 to 1.0).
     * Same day: 1.0
     * Within 1 day: 0.9
     * Within 3 days: 0.75
     * Within 7 days: 0.5
     * Within 14 days: 0.25
     * Beyond 14 days: 0.0
     */
    public static double computeDateProximity(LocalDate date1, LocalDate date2) {
        if (date1 == null || date2 == null) {
            return 0.0;
        }
        long daysDiff = Math.abs(ChronoUnit.DAYS.between(date1, date2));
        if (daysDiff == 0) {
            return 1.0;
        } else if (daysDiff <= 1) {
            return 0.90;
        } else if (daysDiff <= 3) {
            return 0.75;
        } else if (daysDiff <= 7) {
            return 0.50;
        } else if (daysDiff <= 14) {
            return 0.25;
        } else {
            return 0.0;
        }
    }
}
