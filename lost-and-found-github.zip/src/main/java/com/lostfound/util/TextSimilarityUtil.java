package com.lostfound.util;

import java.util.*;
import java.util.stream.Collectors;

public class TextSimilarityUtil {

    private static final Set<String> STOP_WORDS = Set.of(
        "a", "an", "the", "in", "on", "at", "of", "with", "and", "or", "for", "to",
        "is", "was", "my", "your", "by", "from", "it", "this", "that", "i", "me"
    );

    /**
     * Tokenizes and normalizes text: lowercases, removes non-alphanumeric, and filters stop words.
     */
    public static Set<String> extractMeaningfulTokens(String text) {
        if (text == null || text.isBlank()) {
            return Collections.emptySet();
        }
        return Arrays.stream(text.toLowerCase().replaceAll("[^a-z0-9\\s]", " ").split("\\s+"))
                .filter(token -> token.length() > 1 && !STOP_WORDS.contains(token))
                .collect(Collectors.toSet());
    }

    /**
     * Calculates Jaccard similarity score between two token sets (0.0 to 1.0).
     */
    public static double jaccardSimilarity(Set<String> set1, Set<String> set2) {
        if (set1.isEmpty() || set2.isEmpty()) {
            return 0.0;
        }
        Set<String> intersection = new HashSet<>(set1);
        intersection.retainAll(set2);

        Set<String> union = new HashSet<>(set1);
        union.addAll(set2);

        return (double) intersection.size() / union.size();
    }

    /**
     * Calculates Levenshtein-based string similarity (0.0 to 1.0).
     */
    public static double levenshteinSimilarity(String s1, String s2) {
        if (s1 == null || s2 == null) {
            return 0.0;
        }
        String clean1 = s1.trim().toLowerCase();
        String clean2 = s2.trim().toLowerCase();
        if (clean1.equals(clean2)) {
            return 1.0;
        }
        int maxLen = Math.max(clean1.length(), clean2.length());
        if (maxLen == 0) {
            return 1.0;
        }
        int distance = computeLevenshteinDistance(clean1, clean2);
        return 1.0 - ((double) distance / maxLen);
    }

    private static int computeLevenshteinDistance(String a, String b) {
        int[] costs = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) {
            costs[j] = j;
        }
        for (int i = 1; i <= a.length(); i++) {
            costs[0] = i;
            int nw = i - 1;
            for (int j = 1; j <= b.length(); j++) {
                int cj = Math.min(1 + Math.min(costs[j], costs[j - 1]),
                        a.charAt(i - 1) == b.charAt(j - 1) ? nw : nw + 1);
                nw = costs[j];
                costs[j] = cj;
            }
        }
        return costs[b.length()];
    }

    /**
     * Computes combined name similarity using both token overlap and string distance.
     */
    public static double computeNameSimilarity(String name1, String name2) {
        if (name1 == null || name2 == null) {
            return 0.0;
        }
        Set<String> tokens1 = extractMeaningfulTokens(name1);
        Set<String> tokens2 = extractMeaningfulTokens(name2);

        double jaccard = jaccardSimilarity(tokens1, tokens2);
        double levenshtein = levenshteinSimilarity(name1, name2);

        // Weigh token overlap higher for title phrases
        return Math.max(jaccard * 0.7 + levenshtein * 0.3, levenshtein);
    }

    /**
     * Computes location similarity based on token overlap and partial match.
     */
    public static double computeLocationSimilarity(String loc1, String loc2) {
        if (loc1 == null || loc2 == null) {
            return 0.0;
        }
        String clean1 = loc1.trim().toLowerCase();
        String clean2 = loc2.trim().toLowerCase();

        if (clean1.equals(clean2)) {
            return 1.0;
        }
        if (clean1.contains(clean2) || clean2.contains(clean1)) {
            return 0.85;
        }
        Set<String> t1 = extractMeaningfulTokens(clean1);
        Set<String> t2 = extractMeaningfulTokens(clean2);
        return jaccardSimilarity(t1, t2);
    }
}
