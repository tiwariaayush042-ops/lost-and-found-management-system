package com.lostfound.dto;

import com.lostfound.enums.ItemCategory;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PastOrPresent;
import jakarta.validation.constraints.Size;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;

public class FoundItemDto {

    private Long id;

    @NotBlank(message = "Item name is required")
    @Size(min = 2, max = 150, message = "Item name must be between 2 and 150 characters")
    private String title;

    @NotNull(message = "Please select an item category")
    private ItemCategory category;

    @NotBlank(message = "Please provide a detailed description of the found item")
    @Size(min = 5, message = "Description must be at least 5 characters")
    private String description;

    @NotBlank(message = "Please specify where on campus the item was found")
    @Size(max = 150, message = "Location must not exceed 150 characters")
    private String locationFound;

    @NotNull(message = "Date found is required")
    @PastOrPresent(message = "Date found cannot be in the future")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private LocalDate dateFound;

    private String timeFoundApprox;

    private MultipartFile image;

    private String existingImagePath;

    public FoundItemDto() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public ItemCategory getCategory() {
        return category;
    }

    public void setCategory(ItemCategory category) {
        this.category = category;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLocationFound() {
        return locationFound;
    }

    public void setLocationFound(String locationFound) {
        this.locationFound = locationFound;
    }

    public LocalDate getDateFound() {
        return dateFound;
    }

    public void setDateFound(LocalDate dateFound) {
        this.dateFound = dateFound;
    }

    public String getTimeFoundApprox() {
        return timeFoundApprox;
    }

    public void setTimeFoundApprox(String timeFoundApprox) {
        this.timeFoundApprox = timeFoundApprox;
    }

    public MultipartFile getImage() {
        return image;
    }

    public void setImage(MultipartFile image) {
        this.image = image;
    }

    public String getExistingImagePath() {
        return existingImagePath;
    }

    public void setExistingImagePath(String existingImagePath) {
        this.existingImagePath = existingImagePath;
    }
}
