package com.lostfound.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class ClaimRequestDto {

    private Long foundItemId;

    @NotBlank(message = "Please provide detailed proof of ownership or identifying characteristics")
    @Size(min = 10, max = 2000, message = "Evidence description must be between 10 and 2000 characters")
    private String evidenceDescription;

    public ClaimRequestDto() {
    }

    public Long getFoundItemId() {
        return foundItemId;
    }

    public void setFoundItemId(Long foundItemId) {
        this.foundItemId = foundItemId;
    }

    public String getEvidenceDescription() {
        return evidenceDescription;
    }

    public void setEvidenceDescription(String evidenceDescription) {
        this.evidenceDescription = evidenceDescription;
    }
}
