package com.lostfound.dto;

import java.util.List;
import java.util.Map;

public class DashboardStatsDto {

    private long activeLostCount;
    private long availableFoundCount;
    private long returnedCount;
    private long pendingClaimsCount;
    private long totalUsersCount;
    private double recoveryRate; // Percentage e.g. 75.0%
    private List<LocationStat> topLocations;
    private Map<String, Long> categoryDistribution;

    public DashboardStatsDto() {
    }

    public static class LocationStat {
        private String location;
        private long count;

        public LocationStat(String location, long count) {
            this.location = location;
            this.count = count;
        }

        public String getLocation() {
            return location;
        }

        public long getCount() {
            return count;
        }
    }

    // Getters and Setters
    public long getActiveLostCount() {
        return activeLostCount;
    }

    public void setActiveLostCount(long activeLostCount) {
        this.activeLostCount = activeLostCount;
    }

    public long getAvailableFoundCount() {
        return availableFoundCount;
    }

    public void setAvailableFoundCount(long availableFoundCount) {
        this.availableFoundCount = availableFoundCount;
    }

    public long getReturnedCount() {
        return returnedCount;
    }

    public void setReturnedCount(long returnedCount) {
        this.returnedCount = returnedCount;
    }

    public long getPendingClaimsCount() {
        return pendingClaimsCount;
    }

    public void setPendingClaimsCount(long pendingClaimsCount) {
        this.pendingClaimsCount = pendingClaimsCount;
    }

    public long getTotalUsersCount() {
        return totalUsersCount;
    }

    public void setTotalUsersCount(long totalUsersCount) {
        this.totalUsersCount = totalUsersCount;
    }

    public double getRecoveryRate() {
        return recoveryRate;
    }

    public void setRecoveryRate(double recoveryRate) {
        this.recoveryRate = recoveryRate;
    }

    public List<LocationStat> getTopLocations() {
        return topLocations;
    }

    public void setTopLocations(List<LocationStat> topLocations) {
        this.topLocations = topLocations;
    }

    public Map<String, Long> getCategoryDistribution() {
        return categoryDistribution;
    }

    public void setCategoryDistribution(Map<String, Long> categoryDistribution) {
        this.categoryDistribution = categoryDistribution;
    }
}
