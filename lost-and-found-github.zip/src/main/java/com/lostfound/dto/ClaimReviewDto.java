package com.lostfound.dto;

import com.lostfound.enums.ClaimStatus;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class ClaimReviewDto {

    private Long claimId;

    @NotNull(message = "Please select a review decision")
    private ClaimStatus status; // APPROVED or REJECTED

    @Size(max = 1000, message = "Administrator notes cannot exceed 1000 characters")
    private String adminNotes;

    public ClaimReviewDto() {
    }

    public Long getClaimId() {
        return claimId;
    }

    public void setClaimId(Long claimId) {
        this.claimId = claimId;
    }

    public ClaimStatus getStatus() {
        return status;
    }

    public void setStatus(ClaimStatus status) {
        this.status = status;
    }

    public String getAdminNotes() {
        return adminNotes;
    }

    public void setAdminNotes(String adminNotes) {
        this.adminNotes = adminNotes;
    }
}
