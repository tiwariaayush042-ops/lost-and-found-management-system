// CampusFind JavaScript Utilities
document.addEventListener('DOMContentLoaded', function () {
    // Auto-dismiss alerts after 6 seconds
    const alerts = document.querySelectorAll('.alert-dismissible');
    alerts.forEach(function (alert) {
        setTimeout(function () {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 6000);
    });

    // Image upload preview handler
    const imageInput = document.getElementById('imageUploadInput');
    const imagePreview = document.getElementById('imagePreviewContainer');
    if (imageInput && imagePreview) {
        imageInput.addEventListener('change', function (e) {
            const file = e.target.files[0];
            if (file) {
                // Check file size (5MB max)
                if (file.size > 5 * 1024 * 1024) {
                    alert('File is too large! Maximum allowed image size is 5 MB.');
                    imageInput.value = '';
                    imagePreview.classList.add('d-none');
                    return;
                }
                const reader = new FileReader();
                reader.onload = function (event) {
                    const previewImg = document.getElementById('previewImgTag');
                    if (previewImg) {
                        previewImg.src = event.target.result;
                        imagePreview.classList.remove('d-none');
                    }
                };
                reader.readAsDataURL(file);
            }
        });
    }
});
