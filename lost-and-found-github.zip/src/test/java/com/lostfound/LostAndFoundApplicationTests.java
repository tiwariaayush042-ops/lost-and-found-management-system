package com.lostfound;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("h2")
public class LostAndFoundApplicationTests {

    @Test
    @DisplayName("Context loads successfully with H2 in-memory profile")
    void contextLoads() {
    }
}
