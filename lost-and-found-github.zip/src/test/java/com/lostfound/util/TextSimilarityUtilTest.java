package com.lostfound.util;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

public class TextSimilarityUtilTest {

    @Test
    @DisplayName("Should extract meaningful tokens without stopwords")
    void testExtractMeaningfulTokens() {
        String text = "A lost blue water bottle in the campus cafeteria";
        Set<String> tokens = TextSimilarityUtil.extractMeaningfulTokens(text);

        assertTrue(tokens.contains("lost"));
        assertTrue(tokens.contains("blue"));
        assertTrue(tokens.contains("water"));
        assertTrue(tokens.contains("bottle"));
        assertTrue(tokens.contains("campus"));
        assertTrue(tokens.contains("cafeteria"));
        assertFalse(tokens.contains("the"));
        assertFalse(tokens.contains("in"));
        assertFalse(tokens.contains("a"));
    }

    @Test
    @DisplayName("Should calculate Jaccard similarity correctly")
    void testJaccardSimilarity() {
        Set<String> set1 = Set.of("calculator", "casio", "scientific");
        Set<String> set2 = Set.of("calculator", "casio", "black");

        double sim = TextSimilarityUtil.jaccardSimilarity(set1, set2);
        // intersection = 2, union = 4 -> 0.5
        assertEquals(0.5, sim, 0.01);
    }

    @Test
    @DisplayName("Should calculate Levenshtein similarity accurately")
    void testLevenshteinSimilarity() {
        double exact = TextSimilarityUtil.levenshteinSimilarity("Library", "Library");
        assertEquals(1.0, exact, 0.001);

        double close = TextSimilarityUtil.levenshteinSimilarity("Casio Calculator", "Casio Calculater");
        assertTrue(close > 0.85);

        double diff = TextSimilarityUtil.levenshteinSimilarity("iPhone", "Water Bottle");
        assertTrue(diff < 0.3);
    }

    @Test
    @DisplayName("Should calculate date proximity score")
    void testDateProximity() {
        LocalDate today = LocalDate.now();

        // Same day -> 1.0
        assertEquals(1.0, DateUtil.computeDateProximity(today, today), 0.01);

        // 1 day apart -> 0.90
        assertEquals(0.90, DateUtil.computeDateProximity(today, today.minusDays(1)), 0.01);

        // 3 days apart -> 0.75
        assertEquals(0.75, DateUtil.computeDateProximity(today, today.minusDays(3)), 0.01);

        // 30 days apart -> 0.0
        assertEquals(0.0, DateUtil.computeDateProximity(today, today.minusDays(30)), 0.01);
    }
}
