package com.lostfound.service;

import com.lostfound.dto.UserRegistrationDto;
import com.lostfound.entity.User;
import com.lostfound.enums.Role;
import com.lostfound.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class UserServiceTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @Mock
    private AuditLogService auditLogService;

    private UserService userService;

    @BeforeEach
    void setUp() {
        userService = new UserService(userRepository, passwordEncoder, auditLogService);
    }

    @Test
    @DisplayName("Should successfully register a student with hashed password")
    void testRegisterUserSuccess() {
        UserRegistrationDto dto = new UserRegistrationDto();
        dto.setFullName("Aarav Sharma");
        dto.setEmail("aarav@campus.edu");
        dto.setPassword("Secret@123");
        dto.setConfirmPassword("Secret@123");
        dto.setRole(Role.ROLE_STUDENT);
        dto.setIdentifier("23AIML042");

        when(userRepository.existsByEmail("aarav@campus.edu")).thenReturn(false);
        when(passwordEncoder.encode("Secret@123")).thenReturn("$2a$10$hashedPasswordExample");
        when(userRepository.save(any(User.class))).thenAnswer(invocation -> {
            User u = invocation.getArgument(0);
            u.setId(1L);
            return u;
        });

        User registered = userService.registerUser(dto);

        assertNotNull(registered);
        assertEquals(1L, registered.getId());
        assertEquals("aarav@campus.edu", registered.getEmail());
        assertEquals("$2a$10$hashedPasswordExample", registered.getPassword());
        assertEquals(Role.ROLE_STUDENT, registered.getRole());

        verify(userRepository, times(1)).save(any(User.class));
        verify(auditLogService, times(1)).log(anyString(), anyString(), anyString(), anyString(), anyLong(), anyString());
    }

    @Test
    @DisplayName("Should throw exception when registering with already existing email")
    void testRegisterUserDuplicateEmail() {
        UserRegistrationDto dto = new UserRegistrationDto();
        dto.setFullName("Aarav Sharma");
        dto.setEmail("existing@campus.edu");
        dto.setPassword("Secret@123");
        dto.setConfirmPassword("Secret@123");

        when(userRepository.existsByEmail("existing@campus.edu")).thenReturn(true);

        assertThrows(IllegalArgumentException.class, () -> userService.registerUser(dto));
        verify(userRepository, never()).save(any(User.class));
    }

    @Test
    @DisplayName("Should throw exception when password and confirm password do not match")
    void testRegisterUserPasswordMismatch() {
        UserRegistrationDto dto = new UserRegistrationDto();
        dto.setFullName("Aarav Sharma");
        dto.setEmail("aarav@campus.edu");
        dto.setPassword("PasswordOne");
        dto.setConfirmPassword("PasswordTwo");

        when(userRepository.existsByEmail("aarav@campus.edu")).thenReturn(false);

        assertThrows(IllegalArgumentException.class, () -> userService.registerUser(dto));
        verify(userRepository, never()).save(any(User.class));
    }
}
