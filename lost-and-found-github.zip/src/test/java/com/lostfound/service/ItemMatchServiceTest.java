package com.lostfound.service;

import com.lostfound.entity.FoundItem;
import com.lostfound.entity.LostItem;
import com.lostfound.entity.User;
import com.lostfound.enums.ItemCategory;
import com.lostfound.enums.Role;
import com.lostfound.repository.FoundItemRepository;
import com.lostfound.repository.ItemMatchRepository;
import com.lostfound.repository.LostItemRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
public class ItemMatchServiceTest {

    @Mock
    private ItemMatchRepository itemMatchRepository;

    @Mock
    private LostItemRepository lostItemRepository;

    @Mock
    private FoundItemRepository foundItemRepository;

    @Mock
    private NotificationService notificationService;

    private ItemMatchService matchService;

    @BeforeEach
    void setUp() {
        matchService = new ItemMatchService(itemMatchRepository, lostItemRepository, foundItemRepository, notificationService);
        ReflectionTestUtils.setField(matchService, "categoryWeight", 25);
        ReflectionTestUtils.setField(matchService, "nameWeight", 25);
        ReflectionTestUtils.setField(matchService, "locationWeight", 20);
        ReflectionTestUtils.setField(matchService, "dateWeight", 15);
        ReflectionTestUtils.setField(matchService, "descriptionWeight", 15);
        ReflectionTestUtils.setField(matchService, "matchThreshold", 35);
    }

    @Test
    @DisplayName("Should award high score for identical category, similar title, location and date")
    void testCalculateScoreHighMatch() {
        User u1 = new User("User 1", "u1@campus.edu", "pass", Role.ROLE_STUDENT, "001");
        User u2 = new User("User 2", "u2@campus.edu", "pass", Role.ROLE_STUDENT, "002");

        LocalDate today = LocalDate.now();

        LostItem lost = new LostItem(
                u1, "Casio fx-991EX Scientific Calculator", ItemCategory.CALCULATOR,
                "Black Casio calculator with sticker on back", "Room 204 Block B",
                today, "10:00 AM", null
        );

        FoundItem found = new FoundItem(
                u2, "Casio Scientific Calculator fx-991", ItemCategory.CALCULATOR,
                "Found black calculator on desk in room 204", "Room 204 Block B",
                today, "11:00 AM", null
        );

        ItemMatchService.MatchCalculationResult result = matchService.calculateScore(lost, found);

        assertTrue(result.getTotalScore() >= 75, "Expected high score >= 75 but got " + result.getTotalScore());
        assertTrue(result.getExplanation().contains("category"), "Explanation should mention category");
    }

    @Test
    @DisplayName("Should award low score for completely different items")
    void testCalculateScoreLowMatch() {
        User u1 = new User("User 1", "u1@campus.edu", "pass", Role.ROLE_STUDENT, "001");
        User u2 = new User("User 2", "u2@campus.edu", "pass", Role.ROLE_STUDENT, "002");

        LostItem lost = new LostItem(
                u1, "Student ID Card", ItemCategory.ID_CARD,
                "Lanyard with name Aarav", "Main Library",
                LocalDate.now().minusDays(10), null, null
        );

        FoundItem found = new FoundItem(
                u2, "Steel Water Bottle", ItemCategory.WATER_BOTTLE,
                "Silver Milton water bottle", "Gymnasium",
                LocalDate.now(), null, null
        );

        ItemMatchService.MatchCalculationResult result = matchService.calculateScore(lost, found);

        assertTrue(result.getTotalScore() < 25, "Expected low score < 25 but got " + result.getTotalScore());
    }
}
