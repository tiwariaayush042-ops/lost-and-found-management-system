package com.lostfound.service;

import com.lostfound.dto.ClaimRequestDto;
import com.lostfound.dto.ClaimReviewDto;
import com.lostfound.entity.Claim;
import com.lostfound.entity.FoundItem;
import com.lostfound.entity.User;
import com.lostfound.enums.ClaimStatus;
import com.lostfound.enums.FoundItemStatus;
import com.lostfound.enums.ItemCategory;
import com.lostfound.enums.Role;
import com.lostfound.repository.ClaimRepository;
import com.lostfound.repository.FoundItemRepository;
import com.lostfound.repository.ItemMatchRepository;
import com.lostfound.repository.LostItemRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ClaimServiceTest {

    @Mock
    private ClaimRepository claimRepository;

    @Mock
    private FoundItemRepository foundItemRepository;

    @Mock
    private LostItemRepository lostItemRepository;

    @Mock
    private ItemMatchRepository itemMatchRepository;

    @Mock
    private NotificationService notificationService;

    @Mock
    private AuditLogService auditLogService;

    private ClaimService claimService;

    @BeforeEach
    void setUp() {
        claimService = new ClaimService(
                claimRepository, foundItemRepository, lostItemRepository,
                itemMatchRepository, notificationService, auditLogService
        );
    }

    @Test
    @DisplayName("Should submit claim and change item status to UNDER_CLAIM")
    void testSubmitClaimSuccess() {
        User finder = new User("Finder", "finder@campus.edu", "pass", Role.ROLE_STUDENT, "001");
        finder.setId(10L);

        User claimant = new User("Claimant", "claimant@campus.edu", "pass", Role.ROLE_STUDENT, "002");
        claimant.setId(20L);

        FoundItem item = new FoundItem(
                finder, "Keys", ItemCategory.KEYS, "Honda keys",
                "Library", LocalDate.now(), null, null
        );
        item.setId(100L);
        item.setStatus(FoundItemStatus.AVAILABLE);

        when(foundItemRepository.findById(100L)).thenReturn(Optional.of(item));
        when(claimRepository.existsByFoundItemIdAndClaimantIdAndStatus(100L, 20L, ClaimStatus.PENDING)).thenReturn(false);
        when(claimRepository.save(any(Claim.class))).thenAnswer(i -> {
            Claim c = i.getArgument(0);
            c.setId(500L);
            return c;
        });

        ClaimRequestDto dto = new ClaimRequestDto();
        dto.setFoundItemId(100L);
        dto.setEvidenceDescription("My keys have a red tag and small scratch on the Honda logo.");

        Claim created = claimService.submitClaim(dto, claimant);

        assertNotNull(created);
        assertEquals(500L, created.getId());
        assertEquals(FoundItemStatus.UNDER_CLAIM, item.getStatus());
        verify(foundItemRepository, times(1)).save(item);
        verify(notificationService, times(2)).sendNotification(any(), anyString(), anyString(), any(), anyString());
    }

    @Test
    @DisplayName("Should prevent user from claiming an item they reported found themselves")
    void testSelfClaimRejected() {
        User finder = new User("Finder", "finder@campus.edu", "pass", Role.ROLE_STUDENT, "001");
        finder.setId(10L);

        FoundItem item = new FoundItem(
                finder, "Keys", ItemCategory.KEYS, "Honda keys",
                "Library", LocalDate.now(), null, null
        );
        item.setId(100L);

        when(foundItemRepository.findById(100L)).thenReturn(Optional.of(item));

        ClaimRequestDto dto = new ClaimRequestDto();
        dto.setFoundItemId(100L);
        dto.setEvidenceDescription("These are my keys.");

        assertThrows(IllegalArgumentException.class, () -> claimService.submitClaim(dto, finder));
        verify(claimRepository, never()).save(any(Claim.class));
    }

    @Test
    @DisplayName("Should allow administrator to approve claim and change status to CLAIMED")
    void testReviewClaimApproval() {
        User finder = new User("Finder", "finder@campus.edu", "pass", Role.ROLE_STUDENT, "001");
        finder.setId(10L);

        User claimant = new User("Claimant", "claimant@campus.edu", "pass", Role.ROLE_STUDENT, "002");
        claimant.setId(20L);

        User admin = new User("Admin", "admin@campus.edu", "pass", Role.ROLE_ADMIN, "ADM-01");
        admin.setId(99L);

        FoundItem item = new FoundItem(finder, "Bottle", ItemCategory.WATER_BOTTLE, "Milton", "Gym", LocalDate.now(), null, null);
        item.setId(100L);
        item.setStatus(FoundItemStatus.UNDER_CLAIM);

        Claim claim = new Claim(item, claimant, "Proof evidence description");
        claim.setId(300L);
        claim.setStatus(ClaimStatus.PENDING);

        when(claimRepository.findById(300L)).thenReturn(Optional.of(claim));
        when(claimRepository.save(any(Claim.class))).thenAnswer(i -> i.getArgument(0));

        ClaimReviewDto reviewDto = new ClaimReviewDto();
        reviewDto.setClaimId(300L);
        reviewDto.setStatus(ClaimStatus.APPROVED);
        reviewDto.setAdminNotes("Verified with student ID card. Ready for collection.");

        Claim updated = claimService.reviewClaim(reviewDto, admin);

        assertEquals(ClaimStatus.APPROVED, updated.getStatus());
        assertEquals(FoundItemStatus.CLAIMED, item.getStatus());
        verify(foundItemRepository, times(1)).save(item);
    }
}
