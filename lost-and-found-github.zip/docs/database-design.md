# Database Design Document: lost_found_db

## 1. Database Architecture & ER Diagram
The system database is named `lost_found_db` and implemented using MySQL 8.x with InnoDB storage engine for transactional integrity and foreign key constraint enforcement.

```mermaid
erDiagram
    USERS ||--o{ LOST_ITEMS : "reports"
    USERS ||--o{ FOUND_ITEMS : "registers"
    USERS ||--o{ CLAIMS : "submits"
    USERS ||--o{ CLAIMS : "reviews"
    USERS ||--o{ NOTIFICATIONS : "receives"
    LOST_ITEMS ||--o{ ITEM_MATCHES : "matched_in"
    FOUND_ITEMS ||--o{ ITEM_MATCHES : "matched_in"
    FOUND_ITEMS ||--o{ CLAIMS : "claimed_for"

    USERS {
        bigint id PK
        varchar full_name
        varchar email UK
        varchar password
        varchar role
        varchar identifier
        varchar status
        datetime created_at
    }

    LOST_ITEMS {
        bigint id PK
        bigint reporter_id FK
        varchar title
        varchar category
        text description
        varchar last_known_location
        date date_lost
        varchar time_lost_approx
        varchar image_path
        varchar status
        datetime created_at
        datetime updated_at
    }

    FOUND_ITEMS {
        bigint id PK
        bigint reporter_id FK
        varchar title
        varchar category
        text description
        varchar location_found
        date date_found
        varchar time_found_approx
        varchar image_path
        varchar status
        datetime created_at
        datetime updated_at
    }

    CLAIMS {
        bigint id PK
        bigint found_item_id FK
        bigint claimant_id FK
        text evidence_description
        varchar status
        text admin_notes
        bigint reviewer_id FK
        datetime created_at
        datetime reviewed_at
    }

    ITEM_MATCHES {
        bigint id PK
        bigint lost_item_id FK
        bigint found_item_id FK
        int match_score
        varchar match_explanation
        varchar status
        datetime created_at
    }

    NOTIFICATIONS {
        bigint id PK
        bigint recipient_id FK
        varchar title
        text message
        varchar notification_type
        boolean read_status
        varchar link_url
        datetime created_at
    }

    AUDIT_LOGS {
        bigint id PK
        varchar actor_email
        varchar actor_role
        varchar action
        varchar entity_name
        bigint entity_id
        text description
        datetime timestamp
    }
```

## 2. Table Specifications

### 2.1 `users`
- `id`: BIGINT AUTO_INCREMENT PRIMARY KEY
- `full_name`: VARCHAR(100) NOT NULL
- `email`: VARCHAR(120) NOT NULL UNIQUE (Indexed)
- `password`: VARCHAR(255) NOT NULL (BCrypt hash)
- `role`: VARCHAR(20) NOT NULL (`ROLE_STUDENT`, `ROLE_STAFF`, `ROLE_ADMIN`)
- `identifier`: VARCHAR(50) NULL (Roll Number or Employee ID)
- `status`: VARCHAR(20) NOT NULL DEFAULT 'ACTIVE' (`ACTIVE`, `SUSPENDED`)
- `created_at`: DATETIME NOT NULL

### 2.2 `lost_items`
- `id`: BIGINT AUTO_INCREMENT PRIMARY KEY
- `reporter_id`: BIGINT NOT NULL, FOREIGN KEY REFERENCES `users(id)`
- `title`: VARCHAR(150) NOT NULL
- `category`: VARCHAR(50) NOT NULL (Enum: ID_CARD, WALLET_PURSE, KEYS, etc.)
- `description`: TEXT NOT NULL
- `last_known_location`: VARCHAR(150) NOT NULL
- `date_lost`: DATE NOT NULL
- `time_lost_approx`: VARCHAR(80) NULL
- `image_path`: VARCHAR(255) NULL
- `status`: VARCHAR(30) NOT NULL (`LOST`, `FOUND_MATCHED`, `RESOLVED`, `WITHDRAWN`)
- `created_at`: DATETIME NOT NULL, `updated_at`: DATETIME NOT NULL

### 2.3 `found_items`
- `id`: BIGINT AUTO_INCREMENT PRIMARY KEY
- `reporter_id`: BIGINT NOT NULL, FOREIGN KEY REFERENCES `users(id)`
- `title`: VARCHAR(150) NOT NULL
- `category`: VARCHAR(50) NOT NULL
- `description`: TEXT NOT NULL
- `location_found`: VARCHAR(150) NOT NULL
- `date_found`: DATE NOT NULL
- `time_found_approx`: VARCHAR(80) NULL
- `image_path`: VARCHAR(255) NULL
- `status`: VARCHAR(30) NOT NULL (`AVAILABLE`, `UNDER_CLAIM`, `CLAIMED`, `RETURNED`, `WITHDRAWN`)
- `created_at`: DATETIME NOT NULL, `updated_at`: DATETIME NOT NULL

### 2.4 `claims`
- `id`: BIGINT AUTO_INCREMENT PRIMARY KEY
- `found_item_id`: BIGINT NOT NULL, FOREIGN KEY REFERENCES `found_items(id)`
- `claimant_id`: BIGINT NOT NULL, FOREIGN KEY REFERENCES `users(id)`
- `evidence_description`: TEXT NOT NULL
- `status`: VARCHAR(30) NOT NULL (`PENDING`, `APPROVED`, `REJECTED`, `RETURNED`)
- `admin_notes`: TEXT NULL
- `reviewer_id`: BIGINT NULL, FOREIGN KEY REFERENCES `users(id)`
- `created_at`: DATETIME NOT NULL, `reviewed_at`: DATETIME NULL

### 2.5 `item_matches`
- `id`: BIGINT AUTO_INCREMENT PRIMARY KEY
- `lost_item_id`: BIGINT NOT NULL, FOREIGN KEY REFERENCES `lost_items(id)`
- `found_item_id`: BIGINT NOT NULL, FOREIGN KEY REFERENCES `found_items(id)`
- `match_score`: INT NOT NULL (0 to 100)
- `match_explanation`: VARCHAR(500) NOT NULL
- `status`: VARCHAR(30) NOT NULL (`POTENTIAL`, `CONFIRMED`, `DISMISSED`)
- `created_at`: DATETIME NOT NULL

### 2.6 `notifications`
- `id`: BIGINT AUTO_INCREMENT PRIMARY KEY
- `recipient_id`: BIGINT NOT NULL, FOREIGN KEY REFERENCES `users(id)`
- `title`: VARCHAR(150) NOT NULL
- `message`: TEXT NOT NULL
- `notification_type`: VARCHAR(30) NOT NULL
- `read_status`: BOOLEAN NOT NULL DEFAULT FALSE
- `link_url`: VARCHAR(255) NULL
- `created_at`: DATETIME NOT NULL

### 2.7 `audit_logs`
- `id`: BIGINT AUTO_INCREMENT PRIMARY KEY
- `actor_email`: VARCHAR(120) NOT NULL
- `actor_role`: VARCHAR(50) NOT NULL
- `action`: VARCHAR(80) NOT NULL
- `entity_name`: VARCHAR(80) NULL
- `entity_id`: BIGINT NULL
- `description`: TEXT NOT NULL
- `timestamp`: DATETIME NOT NULL
