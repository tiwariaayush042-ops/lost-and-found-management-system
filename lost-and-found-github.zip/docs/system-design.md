# System Architecture & Design: CampusFind

## 1. High-Level Architecture
CampusFind follows the standard **3-Tier Model-View-Controller (MVC)** enterprise architectural pattern powered by Spring Boot 3, Thymeleaf, and MySQL.

```mermaid
flowchart TD
    subgraph ClientLayer ["Client Layer (Web Browsers)"]
        UI["Responsive HTML5 / CSS3 / JavaScript (Bootstrap 5)"]
    end

    subgraph SecurityLayer ["Security & Routing Layer"]
        Filter["Spring Security 6 (Filter Chain, CSRF, BCrypt)"]
    end

    subgraph ControllerLayer ["Presentation Layer (Controllers)"]
        HC["HomeController"]
        AC["AuthController"]
        DC["StudentDashboardController"]
        LC["LostItemController"]
        FC["FoundItemController"]
        SC["SearchController"]
        MC["MatchController"]
        CC["ClaimController"]
        NC["NotificationController"]
        AdmC["AdminController"]
    end

    subgraph ServiceLayer ["Business Logic Layer (Services)"]
        US["UserService"]
        LIS["LostItemService"]
        FIS["FoundItemService"]
        IMS["ItemMatchService (Rule-Based AI Heuristic)"]
        CS["ClaimService (Handover Lifecycle)"]
        NS["NotificationService"]
        ALS["AuditLogService"]
        FSS["FileStorageService (Uploads & Safety)"]
        DS["DashboardService (Analytics)"]
    end

    subgraph DataLayer ["Data Access & Persistence Layer"]
        Repos["Spring Data JPA Repositories"]
        DB[("MySQL 8.x Database (lost_found_db)")]
        Disk[("Local Upload Directory (uploads/)")]
    end

    UI -->|HTTP Requests| Filter
    Filter --> ControllerLayer
    ControllerLayer --> ServiceLayer
    ServiceLayer --> Repos
    FSS --> Disk
    Repos --> DB
```

## 2. Key Architectural Modules

### 2.1 Authentication & Authorization Module
- **Spring Security 6**: Integrates `DaoAuthenticationProvider` and `CustomUserDetailsService`.
- **BCrypt Password Hashing**: Every credential is salt-hashed before database storage.
- **CSRF Token Injection**: Embedded into all state-altering POST forms.
- **Role Hierarchy**:
  - `ROLE_STUDENT`: Browse, search, report lost/found, view matches, submit claims.
  - `ROLE_STAFF`: Student rights plus claim review assistance.
  - `ROLE_ADMIN`: System-wide access, claim approval/rejection, return verification, user status moderation, full audit history.

### 2.2 Smart Potential Item Matching Engine
A deterministic, rule-based algorithm compares newly submitted or updated lost reports against available found items.

```mermaid
flowchart LR
    Report["Lost / Found Item Saved"] --> CategoryCheck{"Category Match?<br/>(25 pts)"}
    CategoryCheck --> TitleCheck["Title Similarity<br/>(Jaccard + Levenshtein, up to 25 pts)"]
    TitleCheck --> LocCheck["Location Similarity<br/>(Token Overlap, up to 20 pts)"]
    LocCheck --> DateCheck["Date Proximity<br/>(Days Difference, up to 15 pts)"]
    DateCheck --> DescCheck["Description Tokens<br/>(Stopword Filtering, up to 15 pts)"]
    DescCheck --> TotalScore["Total Score (0 to 100)"]
    TotalScore --> ThresholdCheck{"Score >= 35%?"}
    ThresholdCheck -->|Yes| SaveMatch["Save ItemMatch with Explanation"]
    ThresholdCheck -->|No| Discard["Discard Match"]
    SaveMatch --> NotifCheck{"Score >= 50%?"}
    NotifCheck -->|Yes| PushNotif["Dispatch In-App Notification"]
    NotifCheck -->|No| EndMatch["End"]
```

### 2.3 Ownership Claim & Physical Handover Workflow
```mermaid
sequenceDiagram
    autonumber
    actor Claimant as Student Owner
    participant Web as CampusFind Web
    actor Admin as Campus Admin
    actor Finder as Good Samaritan

    Finder->>Web: Register Found Item (Status: AVAILABLE)
    Claimant->>Web: Browse or view Algorithmic Match
    Claimant->>Web: Submit Claim with Evidence / Marks
    Note over Web: Status transitions to UNDER_CLAIM
    Web->>Admin: Pending Claim Alert
    Admin->>Web: Review Evidence (Approve / Reject)
    alt Claim Approved
        Note over Web: Status transitions to CLAIMED
        Web->>Claimant: Notification: Visit Admin Desk Room 102
        Claimant->>Admin: In-person ID & Physical Verification
        Admin->>Web: Confirm Handover & Return
        Note over Web: Status transitions to RETURNED
        Web->>Finder: Thank-you notification
        Web->>Claimant: Recovery confirmation notification
    else Claim Rejected
        Note over Web: Status reverts to AVAILABLE
        Web->>Claimant: Rejection reason notification
    end
```
