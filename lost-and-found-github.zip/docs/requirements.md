# Software Requirements Specification (SRS): CampusFind

## 1. Functional Requirements

### FR-1: User Management & Authentication
- **FR-1.1**: The system shall permit campus students and faculty to self-register with Name, valid Email, Password, Role, and optional Student/Staff Roll Number.
- **FR-1.2**: Passwords must be encoded using BCrypt with salt rounds before database persistence.
- **FR-1.3**: The system shall enforce role-based access control (Student: `ROLE_STUDENT`, Staff: `ROLE_STAFF`, Admin: `ROLE_ADMIN`).
- **FR-1.4**: Public registration shall not permit direct registration into the Administrator role.
- **FR-1.5**: Administrators shall be capable of suspending or re-activating user accounts.

### FR-2: Lost Item Reporting
- **FR-2.1**: Authenticated users can register lost items specifying Title, Category, Description, Last Known Location, Date Lost, Approximate Time, and optional Photograph.
- **FR-2.2**: Uploaded photos must undergo MIME-type, extension, and 5MB size validation.
- **FR-2.3**: Reports can be edited or withdrawn only by their original reporter or an administrator.

### FR-3: Found Item Registration
- **FR-3.1**: Authenticated campus members can lodge found items specifying Category, Title, Location Found, Date, Time, Description, and Photograph.
- **FR-3.2**: Found items initialize with the `AVAILABLE` status.

### FR-4: Smart Potential Item Matching
- **FR-4.1**: Upon saving a lost or found report, a transparent rule-based algorithm computes similarity against eligible active items.
- **FR-4.2**: The scoring algorithm applies weights: Category (25 pts), Title Text Similarity (25 pts), Location Proximity (20 pts), Date Proximity (15 pts), and Description Token Overlap (15 pts).
- **FR-4.3**: Items scoring $\ge 35\%$ are recorded as potential matches; scores $\ge 50\%$ trigger automatic in-app notifications.

### FR-5: Ownership Claim & Handover Workflow
- **FR-5.1**: Users can submit an ownership claim on available found items by detailing private proof or distinguishing marks.
- **FR-5.2**: The finder of an item is barred from claiming their own found item. Duplicate pending claims are prevented.
- **FR-5.3**: Submission moves item status to `UNDER_CLAIM`.
- **FR-5.4**: Administrators review claims and record explicit notes when Approving or Rejecting.
- **FR-5.5**: After in-person verification, the administrator confirms physical handover, transitioning status to `RETURNED`.

### FR-6: Analytics & Auditing
- **FR-6.1**: Real-time database metrics display Active Lost, Available Found, Returned Items, Pending Claims, and Recovery Rate.
- **FR-6.2**: All sensitive operations are logged to the `audit_logs` table with timestamp, actor, action, and target entity.

## 2. Non-Functional Requirements
- **NFR-1 (Security)**: CSRF tokens on all state-altering forms, parameterized JPA queries to prevent SQL injection, and path traversal prevention on file uploads.
- **NFR-2 (Performance)**: Paginated database queries with indexed search columns to support smooth operation on low-power devices.
- **NFR-3 (Maintainability)**: Clean 3-tier Spring Boot architecture adhering to separation of concerns.
