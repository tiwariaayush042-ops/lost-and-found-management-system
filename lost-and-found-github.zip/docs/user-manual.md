# CampusFind &mdash; User Manual & Operating Guide

## 1. Getting Started

### 1.1 Accessing the Application
- Open any modern web browser (Google Chrome, Mozilla Firefox, Microsoft Edge, Safari).
- Navigate to `http://localhost:8080/`.

### 1.2 Demo Accounts for Viva Evaluation
The system comes pre-initialized with three ready-to-test accounts:
- **Administrator**: `admin@campus.edu` / `Admin@12345`
- **Student**: `student@campus.edu` / `Student@12345`
- **Faculty / Staff**: `staff@campus.edu` / `Staff@12345`

---

## 2. Student Guide

### 2.1 Registering an Account
1. Click **Register** on the top navigation bar.
2. Enter your Full Name, Campus Email, select **Student** role, enter your Roll Number (e.g. `23AIML042`), and choose a secure password (minimum 6 characters).
3. Click **Register Account**. You will be redirected to the login page with a success message.

### 2.2 Reporting a Lost Belonging
1. Log in and click **Report Item &rarr; Report Lost Item** or click **Report Lost** from your dashboard.
2. Fill out:
   - **Item Name**: Be descriptive (e.g., *Casio fx-991EX Scientific Calculator*).
   - **Category**: Select the relevant category (e.g., *Calculator*).
   - **Last Known Location**: Specify classroom, lab, cafeteria, or library.
   - **Date Lost**: Select the calendar date.
   - **Detailed Description**: Describe identifying marks, stickers, color, or condition.
   - **Optional Photograph**: Upload a reference image (max 5 MB).
3. Click **Submit Lost Report**. The system automatically triggers the rule-based matching engine against all available found items.

### 2.3 Viewing Smart Matches
1. Open your report details page or navigate to **My Lost Reports**.
2. Click the **Matches** button next to your item.
3. Review the **Match Score (0-100%)** and **Match Explanation**.
4. If a match corresponds to your belonging, click **Claim This Item &rarr;**.

### 2.4 Submitting an Ownership Claim
1. On the found item details page, click **Submit Ownership Claim**.
2. Enter verifiable ownership proof (e.g. contents of wallet, laptop wallpaper, serial number, or student ID).
3. Submit the claim. The item transitions to `UNDER_CLAIM` status.

---

## 3. Administrator Guide

### 3.1 Accessing the Admin Dashboard
1. Log in with an administrator account (`admin@campus.edu`).
2. Click **Admin Dashboard** in the top navigation bar.
3. Review genuine database statistics: Active Lost, Available Found, Returned Items, Pending Claims, and the Campus Recovery Rate.

### 3.2 Reviewing Ownership Claims
1. In the admin dashboard, click **Review Claims**.
2. Examine the claimant's submitted evidence description.
3. Click **Review Claim**:
   - Choose **Approve** if proof matches.
   - Choose **Reject** if fraudulent or insufficient, entering an explanation.
4. Click **Submit Decision**. The student is automatically notified in-app.

### 3.3 Confirming Physical Handover
1. When the student arrives at the Campus Lost & Found Office with their physical ID card, locate the approved claim.
2. Click **Confirm Handover & Return**.
3. The item status transitions to `RETURNED`. The matched lost item is marked `RESOLVED`.
4. The event is permanently logged into the immutable audit history.

### 3.4 User Moderation
1. Navigate to **Manage Users** (`/admin/users`).
2. Toggle account status between `Active` and `Suspended` to handle misbehaving accounts.
3. Promote or adjust roles as required.
