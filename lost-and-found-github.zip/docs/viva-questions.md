# Comprehensive Project Review & Viva Preparation Guide
*Tailored for 2nd-Year AIML Undergraduate Project Review & Oral Examination*

---

## 1. Core Framework & Architecture Questions

### Q1: What is Spring Boot, and why did you choose it over standard Spring or Servlets?
**Answer:**
Spring Boot is an enterprise Java framework built on top of the Spring framework. It eliminates complex XML boilerplate through **Auto-Configuration** and provides an **embedded web server (Apache Tomcat)**, allowing our application to run directly as a standalone `.jar` file without requiring external server installations. For our Lost and Found project, it provides seamless starters for Spring Data JPA, Spring Security, Validation, and Thymeleaf templates.

### Q2: Explain the Model-View-Controller (MVC) architectural pattern in your project.
**Answer:**
We structured the application strictly using the 3-Tier MVC architecture:
1. **Model**: Represents data and business domain entities (`LostItem.java`, `FoundItem.java`, `Claim.java`, `User.java`) mapped to MySQL database tables using JPA/Hibernate annotations.
2. **View**: Server-rendered Thymeleaf HTML5 templates in `src/main/resources/templates/` that dynamically inject model attributes into web pages using `th:text`, `th:href`, and `th:if`.
3. **Controller**: Java classes in `com.lostfound.controller` (`LostItemController`, `ClaimController`, `AdminController`) that handle HTTP GET and POST requests, validate form DTOs, invoke business services, and return view names.

### Q3: Why did your team use Thymeleaf instead of a separate React/Vue single-page application?
**Answer:**
1. **Simplified Deployment & Build Process**: Thymeleaf runs directly inside the Spring Boot container via Maven. There is no separate Node.js build pipeline, npm packaging, or CORS configuration required.
2. **Native Spring Security & CSRF Integration**: Form authentication, role-based visibility (`sec:authorize="hasRole('ADMIN')"`), and CSRF tokens are injected natively into templates.
3. **Appropriate for Academic Scope**: For a second-year AIML project team, Thymeleaf ensures clean, readable, server-side rendered HTML that is transparent to explain during a viva review.

---

## 2. Security & Authentication Questions

### Q4: How is user authentication implemented in CampusFind?
**Answer:**
We implemented authentication using **Spring Security 6**.
- In `SecurityConfig.java`, we define a `SecurityFilterChain` bean.
- When a user submits the login form, Spring Security invokes `CustomUserDetailsService.loadUserByUsername(email)`.
- It fetches the `User` entity from the `users` table via `UserRepository.findByEmail(email)`.
- If the user's status is `SUSPENDED`, it throws a `DisabledException`.
- It converts the entity's role (`ROLE_STUDENT`, `ROLE_STAFF`, `ROLE_ADMIN`) into a Spring Security `SimpleGrantedAuthority`.

### Q5: How do you protect passwords in the database?
**Answer:**
We never store plain text passwords. We use Spring Security's `BCryptPasswordEncoder`. BCrypt uses a one-way mathematical hashing algorithm combined with a random 16-byte salt and configurable work factor (default 10 rounds). When a user registers in `UserService.registerUser()`, their password is encrypted using `passwordEncoder.encode(rawPassword)`. During login, BCrypt matches the incoming password hash against the stored hash using `matches()`, protecting passwords against dictionary and rainbow-table attacks.

### Q6: What is CSRF, and how is your application protected?
**Answer:**
CSRF (Cross-Site Request Forgery) occurs when a malicious website tricks an authenticated user's browser into performing an unauthorized action on another site. Spring Security enables CSRF protection by default. Every HTML form (such as reporting an item, submitting a claim, or logging in) includes a hidden unique token parameter:
```html
<input type="hidden" th:name="${_csrf.parameterName}" th:value="${_csrf.token}"/>
```
If an incoming POST request lacks this token or has an invalid token, the server immediately rejects the request with HTTP 403.

### Q7: How do you prevent Path Traversal attacks during image upload?
**Answer:**
In `FileStorageService.java`:
1. We clean the input filename using `StringUtils.cleanPath()`.
2. We explicitly check if the filename contains relative directory traversal characters (`..`). If found, a `FileStorageException` is raised.
3. We do not store files with their user-supplied names; instead, we generate a cryptographically random `UUID.randomUUID().toString() + "." + extension`.
4. We store files outside of executable application classpaths and strictly validate file extensions (`.jpg`, `.jpeg`, `.png`, `.webp`) and MIME types (`image/jpeg`, etc.).

---

## 3. Database & JPA Questions

### Q8: What database are you using, and how does Spring Boot talk to it?
**Answer:**
We use **MySQL 8.x** as the primary relational database (`lost_found_db`) via **Spring Data JPA** and the **Hibernate ORM** (Object-Relational Mapping). We also include an in-memory **H2 database profile** for automated testing and immediate demonstration. Hibernate automatically maps Java entity classes (`@Entity`) and annotations (`@Table`, `@Column`, `@ManyToOne`, `@JoinColumn`) to relational SQL tables and constraints without needing manual SQL query writing.

### Q9: Explain the entity relationships in your database.
**Answer:**
- **User to LostItem / FoundItem**: `@OneToMany` / `@ManyToOne`. One student or staff member can report multiple lost items or found items, but each item has exactly one reporter.
- **FoundItem to Claim**: `@OneToMany` / `@ManyToOne`. A found item can have multiple competing claims from different students, but each claim belongs to exactly one found item.
- **LostItem / FoundItem to ItemMatch**: `@ManyToOne`. An `ItemMatch` entity joins one `LostItem` and one `FoundItem` with a computed match score and explanation.
- **User to Notification**: `@OneToMany` / `@ManyToOne`. A user can receive many notifications.

### Q10: How do you prevent SQL Injection in search queries?
**Answer:**
In `LostItemRepository.java` and `FoundItemRepository.java`, we use JPA parameterized queries with `@Param`:
```java
@Query("SELECT l FROM LostItem l WHERE (:keyword IS NULL OR LOWER(l.title) LIKE LOWER(CONCAT('%', :keyword, '%')))...")
```
Hibernate transforms these into JDBC `PreparedStatement` parameters with placeholders (`?`). The database driver escapes input strings as literals rather than executable SQL fragments, rendering SQL injection impossible.

---

## 4. Smart Matching Algorithm Questions

### Q11: Explain your rule-based potential item matching algorithm. Is it an external API or built from scratch?
**Answer:**
The matching algorithm in `ItemMatchService.java` is built completely in pure Java without external paid APIs. It evaluates 5 deterministic features totaling a maximum score of 100 points:
1. **Category Match (25 points)**: Exact match between `ItemCategory` enums (e.g. `CALCULATOR == CALCULATOR`).
2. **Title Text Similarity (up to 25 points)**: Combines token overlap using the **Jaccard Similarity Coefficient** with normalized **Levenshtein Edit Distance** in `TextSimilarityUtil.java`.
3. **Location Proximity (up to 20 points)**: Normalizes campus location names and computes word overlap (e.g., matching "Library 2nd Floor" with "Central Library Reading Room").
4. **Date Proximity (up to 15 points)**: Evaluated in `DateUtil.java` using chronological difference: same day (100%), 1 day apart (90%), 3 days (75%), 7 days (50%), $\gt 14$ days (0%).
5. **Description Keyword Overlap (up to 15 points)**: Filters common English stopwords ("the", "in", "a", "my") and computes Jaccard token overlap across item descriptions.

If total score $\ge 35\%$, a match is persisted with an explanation string. If $\ge 50\%$, an automated notification is dispatched to the lost item owner.

### Q12: Why did you not automatically mark an item as returned when the match score is 100%?
**Answer:**
A match score is a **statistical heuristic**, not absolute legal proof of ownership. For example, two students may lose identical black Casio calculators in the library on the same day. Automatic resolution would risk handing belongings to the wrong student. Therefore, the system enforces **Human Verification**: the owner must submit a claim with specific private proof (e.g. scratch, sticker, or serial number), an administrator must verify the evidence, and an in-person handover with student ID verification must take place.

---

## 5. Lifecycle & Business Logic Questions

### Q13: Walk us through the Claim and Return Lifecycle.
**Answer:**
1. **Found Report Registered**: Finder submits report &rarr; status is `AVAILABLE`.
2. **Claim Submitted**: Another campus member submits a claim with proof &rarr; item status transitions to `UNDER_CLAIM`; claim status is `PENDING`.
3. **Admin Review**: Administrator inspects evidence in `/admin/claims`:
   - If rejected: claim set to `REJECTED`, item returns to `AVAILABLE`.
   - If approved: claim set to `APPROVED`, item set to `CLAIMED`, notification sent to claimant with pickup instructions.
4. **Physical Handover**: Student visits Lost & Found desk with student ID card. Administrator clicks **Confirm Handover & Return** &rarr; claim and found item statuses become `RETURNED`, and claimant's matching lost report is marked `RESOLVED`.
5. **Audit Logging**: Every action is saved into `audit_logs`.

### Q14: How does the system prevent a user from claiming an item they reported found themselves?
**Answer:**
In `ClaimService.submitClaim()`:
```java
if (foundItem.getReporter().getId().equals(claimant.getId())) {
    throw new IllegalArgumentException("You cannot submit an ownership claim for an item you reported as found.");
}
```
We also enforce this on the frontend by hiding the claim button for the reporter in `found-details.html`.
