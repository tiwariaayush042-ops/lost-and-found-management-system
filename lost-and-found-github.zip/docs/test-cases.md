# Comprehensive Test Cases: CampusFind

## 1. Automated Test Suite Summary
- **Framework**: JUnit 5, Mockito, Spring Boot Test, Spring Security Test, MockMvc
- **Test Results**: 16/16 Passed (100% Success Rate)

| Test Suite | Class Name | Cases | Status |
| :--- | :--- | :---: | :---: |
| Text Tokenization & Distance | `TextSimilarityUtilTest` | 4 | PASSED |
| Smart Match Algorithm | `ItemMatchServiceTest` | 2 | PASSED |
| User Security & Registration | `UserServiceTest` | 3 | PASSED |
| Claims & Return Lifecycle | `ClaimServiceTest` | 3 | PASSED |
| Auth & Validation (MockMvc) | `AuthControllerTest` | 3 | PASSED |
| Context Integration | `LostAndFoundApplicationTests` | 1 | PASSED |

---

## 2. Detailed Test Cases Matrix

### TC-01: User Self-Registration
- **Description**: Validates registration with valid full name, campus email, password, and roll number.
- **Input**: `fullName="Aarav Sharma"`, `email="aarav@campus.edu"`, `password="Secret@123"`, `confirmPassword="Secret@123"`, `role=ROLE_STUDENT`
- **Expected Outcome**: New user created with BCrypt encoded password, default `ACTIVE` status, audit log generated.
- **Verification**: `UserServiceTest.testRegisterUserSuccess` &rarr; **PASSED**.

### TC-02: Duplicate Email Rejection
- **Description**: Ensures duplicate user accounts cannot be created with identical email addresses.
- **Input**: Existing email address.
- **Expected Outcome**: `IllegalArgumentException` thrown; persistence rejected.
- **Verification**: `UserServiceTest.testRegisterUserDuplicateEmail` &rarr; **PASSED**.

### TC-03: Password Mismatch Validation
- **Description**: Verifies that mismatch between password and confirmation is caught server-side.
- **Input**: `password="PasswordOne"`, `confirmPassword="PasswordTwo"`.
- **Expected Outcome**: `IllegalArgumentException` thrown.
- **Verification**: `UserServiceTest.testRegisterUserPasswordMismatch` &rarr; **PASSED**.

### TC-04: Stopword Filtering & Token Extraction
- **Description**: Validates that punctuation and English stopwords ("the", "in", "at", "a") are stripped so meaningful keywords are matched.
- **Input**: `"A lost blue water bottle in the campus cafeteria"`
- **Expected Outcome**: Set containing only `["lost", "blue", "water", "bottle", "campus", "cafeteria"]`.
- **Verification**: `TextSimilarityUtilTest.testExtractMeaningfulTokens` &rarr; **PASSED**.

### TC-05: Jaccard Set Similarity
- **Description**: Verifies Jaccard coefficient $\frac{|A \cap B|}{|A \cup B|}$.
- **Input**: Set 1: `{"calculator", "casio", "scientific"}`, Set 2: `{"calculator", "casio", "black"}`
- **Expected Outcome**: $2 / 4 = 0.50$.
- **Verification**: `TextSimilarityUtilTest.testJaccardSimilarity` &rarr; **PASSED**.

### TC-06: Date Proximity Scoring
- **Description**: Validates non-linear date decay function for lost/found proximity.
- **Input**: Days difference of 0, 1, 3, and 30 days.
- **Expected Outcome**: 1.0 (same day), 0.90 (1 day), 0.75 (3 days), 0.0 (30 days).
- **Verification**: `TextSimilarityUtilTest.testDateProximity` &rarr; **PASSED**.

### TC-07: High-Confidence Smart Match Detection
- **Description**: Compares lost Casio Calculator in Room 204 with found Casio Calculator in Room 204.
- **Expected Outcome**: Score $\ge 75/100$, explanation includes category, title, and location similarity.
- **Verification**: `ItemMatchServiceTest.testCalculateScoreHighMatch` &rarr; **PASSED**.

### TC-08: Low-Correlation Match Discrimination
- **Description**: Compares lost Student ID card with found Water Bottle in Gymnasium.
- **Expected Outcome**: Score $< 25/100$; match ignored.
- **Verification**: `ItemMatchServiceTest.testCalculateScoreLowMatch` &rarr; **PASSED**.

### TC-09: Ownership Claim Submission
- **Description**: Submits claim with distinguishing ownership marks.
- **Expected Outcome**: Item status transitions from `AVAILABLE` to `UNDER_CLAIM`; notification dispatched to claimant and finder.
- **Verification**: `ClaimServiceTest.testSubmitClaimSuccess` &rarr; **PASSED**.

### TC-10: Self-Claim Prevention
- **Description**: Ensures user cannot submit an ownership claim for an item they reported as found.
- **Input**: Claimant ID == Finder ID.
- **Expected Outcome**: `IllegalArgumentException` thrown; claim rejected.
- **Verification**: `ClaimServiceTest.testSelfClaimRejected` &rarr; **PASSED**.

### TC-11: Administrator Claim Approval
- **Description**: Administrator approves verified claim with feedback note.
- **Expected Outcome**: Claim status set to `APPROVED`, found item status set to `CLAIMED`, notification dispatched to claimant to visit collection desk.
- **Verification**: `ClaimServiceTest.testReviewClaimApproval` &rarr; **PASSED**.

### TC-12: Physical Handover & Item Return
- **Description**: Administrator verifies physical student ID and completes handover.
- **Expected Outcome**: Status set to `RETURNED`; matched lost report set to `RESOLVED`; recovery recorded in audit log.
- **Verification**: Verified via `ClaimService.markItemAsReturned`.
